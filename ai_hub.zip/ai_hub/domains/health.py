"""Symptom triage - an EDUCATIONAL demo, not medical advice.

* Red-flag rules - certain symptoms always mean "emergency", no model involved.
* ANN   - urgency class (self-care / clinic / emergency) from symptoms, duration, age.
* PSO   - tunes the decision thresholds so that under-triage costs more than over-triage.
* GA    - finds the smallest set of questions that keeps triage quality high.
* A*    - route to the nearest suitable facility (via the trip planner's road graph).

The model is trained on rule-generated synthetic cases so the pipeline can be
demonstrated end to end. A real system needs clinician-validated data and review.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from core.nn import MLP, load_or_train
from core.optimize import ga_binary, pso

SYMPTOMS = [
    ("fever", "Fever", 1.0),
    ("cough", "Cough", 0.6),
    ("sore_throat", "Sore throat", 0.4),
    ("headache", "Headache", 0.5),
    ("fatigue", "Unusual tiredness", 0.4),
    ("muscle_ache", "Muscle aches", 0.4),
    ("diarrhea", "Diarrhea", 0.8),
    ("vomiting", "Vomiting", 0.9),
    ("abdominal_pain", "Abdominal pain", 1.0),
    ("rash", "Skin rash", 0.6),
    ("loss_of_smell", "Loss of smell or taste", 0.3),
    ("dehydration_signs", "Dehydration (very dry mouth, little urine)", 1.6),
]
RED_FLAGS = [
    ("chest_pain", "Chest pain or pressure"),
    ("shortness_of_breath", "Severe difficulty breathing"),
    ("confusion", "Confusion or fainting"),
    ("severe_bleeding", "Heavy bleeding that will not stop"),
    ("stiff_neck", "Stiff neck with fever"),
]
AGES = ["child", "adult", "older"]
LEVELS = ["self_care", "clinic", "emergency"]
LEVEL_LABELS = {"self_care": "Self-care at home", "clinic": "See a clinic today",
                "emergency": "Emergency - go now"}
ADVICE = {
    "self_care": "Rest, drink fluids and monitor. See a clinic if symptoms last more than 48 hours "
                 "or get worse.",
    "clinic": "See a health professional within 24 hours. Go sooner if symptoms get worse.",
    "emergency": "Seek emergency care now. Do not wait, and do not travel alone if you can avoid it.",
}
DISCLAIMER = ("Educational demo trained on synthetic data. It is not a diagnosis or medical advice. "
              "If you are worried, contact a health professional or your local emergency number.")

_W = np.array([s[2] for s in SYMPTOMS])
_IDX = {s[0]: i for i, s in enumerate(SYMPTOMS)}
T1, T2 = 2.6, 5.6                       # hidden thresholds of the synthetic labelling rule
UNDER_COST, OVER_COST = 4.0, 1.0        # under-triage is 4x worse than over-triage
N_FEATURES = len(SYMPTOMS) + 1 + len(AGES)


def encode(symptoms, days, age):
    v = np.zeros(N_FEATURES)
    for s in symptoms:
        if s in _IDX:
            v[_IDX[s]] = 1.0
    v[len(SYMPTOMS)] = min(max(float(days), 0.0), 14.0) / 14.0
    v[len(SYMPTOMS) + 1 + AGES.index(age)] = 1.0
    return v


def synth_cases(rng, n):
    p = rng.uniform(0.04, 0.55, (n, 1))
    S = (rng.random((n, len(SYMPTOMS))) < p).astype(float)
    days = rng.integers(0, 15, n).astype(float)
    age = rng.choice(3, n, p=[0.2, 0.65, 0.15])
    risk = (S @ _W + 0.18 * np.clip(days - 2, 0, 8) + np.array([0.7, 0.0, 0.9])[age]
            + 0.8 * S[:, _IDX["vomiting"]] * S[:, _IDX["diarrhea"]]
            + 0.5 * S[:, _IDX["fever"]] * S[:, _IDX["cough"]] * S[:, _IDX["fatigue"]]
            + rng.normal(0, 0.3, n))
    y = (risk >= T1).astype(int) + (risk >= T2).astype(int)
    X = np.column_stack([S, days / 14.0, np.eye(3)[age]])
    return X, y


def severity(probs):
    """Expected urgency in [0, 2]: p(clinic) + 2 * p(emergency)."""
    return probs[:, 1] + 2.0 * probs[:, 2]


def levels_from_score(score, t1, gap):
    return (score >= t1).astype(int) + (score >= t1 + gap).astype(int)


def triage_cost(y, pred):
    d = pred - y
    return float(np.sum(np.where(d < 0, -d * UNDER_COST, d * OVER_COST)))


def _under_rate(y, pred):
    return float(np.mean(pred < y))


class HealthTriage:
    VERSION = "health-v2"

    def __init__(self, mlp, metrics, trip):
        self.mlp = mlp
        self.metrics = metrics
        self.trip = trip
        self.t1 = metrics["thresholds"]["t1"]
        self.gap = metrics["thresholds"]["gap"]

    @classmethod
    def build(cls, model_dir, trip, retrain=False):
        def train():
            rng = np.random.default_rng(21)
            X, y = synth_cases(rng, 9000)
            Xtr, ytr = X[:6000], y[:6000]
            Xva, yva = X[6000:7500], y[6000:7500]
            Xte, yte = X[7500:], y[7500:]
            mlp = MLP([N_FEATURES, 24, 12, 3], "classification", "tanh", seed=4)
            mlp.fit(Xtr, ytr, epochs=60, lr=0.01, batch=64)
            acc = float(np.mean(mlp.predict_class(Xte) == yte))

            score_va = severity(mlp.predict(Xva))
            score_te = severity(mlp.predict(Xte))
            fit = pso(lambda t: triage_cost(yva, levels_from_score(score_va, t[0], t[1])),
                      [(0.02, 1.0), (0.2, 1.2)], particles=20, iters=40, seed=5)
            t1, gap = fit["x"]
            argmax_pred = mlp.predict_class(Xte)
            tuned_pred = levels_from_score(score_te, t1, gap)

            # GA: smallest useful question set, judged on validation cost
            def masked_cost(bits):
                Xm = Xva.copy()
                for i, b in enumerate(bits):
                    if not b:
                        Xm[:, i] = 0.0
                sc = severity(mlp.predict(Xm))
                return triage_cost(yva, levels_from_score(sc, t1, gap)) / len(yva)

            ga = ga_binary(len(SYMPTOMS), lambda bits: -masked_cost(bits) - 0.03 * sum(bits),
                           pop_size=40, generations=40, seed=6, init_prob=0.6,
                           seeds=[[1] * len(SYMPTOMS)])
            bits = ga["best"]
            full_cost = masked_cost([1] * len(SYMPTOMS))
            importance = []
            for i, (sid, label, _) in enumerate(SYMPTOMS):
                b = [1] * len(SYMPTOMS)
                b[i] = 0
                importance.append((sid, label, masked_cost(b) - full_cost))
            importance.sort(key=lambda r: -r[2])
            metrics = {
                "task": "classification", "architecture": f"{N_FEATURES}-24-12-3 tanh",
                "samples": 6000, "accuracy_test": round(acc, 4),
                "thresholds": {"t1": round(float(t1), 4), "gap": round(float(gap), 4)},
                "cost_argmax": round(triage_cost(yte, argmax_pred), 1),
                "cost_tuned": round(triage_cost(yte, tuned_pred), 1),
                "under_triage_argmax": round(_under_rate(yte, argmax_pred), 4),
                "under_triage_tuned": round(_under_rate(yte, tuned_pred), 4),
                "questions": {
                    "selected": [SYMPTOMS[i][0] for i, b in enumerate(bits) if b],
                    "cost_selected": round(masked_cost(bits), 4),
                    "cost_all": round(full_cost, 4),
                    "importance": [{"id": a, "label": b, "extra_cost": round(c, 4)}
                                   for a, b, c in importance],
                },
                "note": "Trained on rule-generated synthetic cases - a demo, not a clinical tool.",
            }
            return mlp, metrics

        mlp, metrics = load_or_train(Path(model_dir) / "health.json", cls.VERSION, train, retrain)
        return cls(mlp, metrics, trip)

    def public_meta(self):
        return {"symptoms": [{"id": i, "label": l} for i, l, _ in SYMPTOMS],
                "red_flags": [{"id": i, "label": l} for i, l in RED_FLAGS],
                "ages": AGES, "disclaimer": DISCLAIMER}

    def questions(self):
        return self.metrics["questions"]

    def triage(self, symptoms, age="adult", days=1, location=None, hour=12.0,
               rain=False, weekend=False):
        known = {s[0] for s in SYMPTOMS} | {r[0] for r in RED_FLAGS}
        bad = [s for s in symptoms if s not in known]
        if bad:
            raise ValueError(f"Unknown symptom(s): {', '.join(bad)}")
        if age not in AGES:
            raise ValueError(f"age must be one of {AGES}")
        if not symptoms:
            raise ValueError("Select at least one symptom.")
        red = [r for r in RED_FLAGS if r[0] in symptoms]
        probs = self.mlp.predict(encode(symptoms, days, age))[0]
        score = float(severity(probs.reshape(1, -1))[0])
        model_level = int(levels_from_score(np.array([score]), self.t1, self.gap)[0])
        if red:
            level, reason = 2, "Red-flag symptom: " + ", ".join(r[1].lower() for r in red)
        else:
            level, reason = model_level, "Model estimate from your symptoms, how long they lasted and age group"
        name = LEVELS[level]
        facility = None
        if location and level >= 1:
            goals = [i for i, n in self.trip.nodes.items()
                     if n["type"] == "hospital" or (n["type"] == "clinic" and level == 1)]
            facility = self.trip.nearest(location, goals, hour, rain, weekend)
            ranked = []
            for g in goals:
                r = self.trip.route(location, g, hour, rain, weekend, compare=False)
                ranked.append({"id": g, "name": self.trip.name(g), "minutes": r["minutes"], "km": r["km"]})
            ranked.sort(key=lambda r: r["minutes"])
            if facility:
                facility["alternatives"] = ranked[:3]
        return {
            "level": name, "level_label": LEVEL_LABELS[name], "advice": ADVICE[name],
            "reason": reason, "red_flags": [r[0] for r in red],
            "probabilities": {n: round(float(p), 3) for n, p in zip(LEVELS, probs)},
            "score": round(score, 3), "facility": facility, "disclaimer": DISCLAIMER,
        }
