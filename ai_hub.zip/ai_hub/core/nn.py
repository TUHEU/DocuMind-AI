"""A small multilayer perceptron written with NumPy only.

Supports regression (linear output, MSE), binary classification (sigmoid, BCE)
and multi-class classification (softmax, cross-entropy), trained with Adam.
Inputs (and regression targets) are standardised internally, so callers can
pass raw feature values.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np


class MLP:
    def __init__(self, sizes, task="regression", hidden="tanh", seed=0):
        if task not in ("regression", "binary", "classification"):
            raise ValueError("task must be regression, binary or classification")
        if hidden not in ("tanh", "relu"):
            raise ValueError("hidden must be tanh or relu")
        self.sizes = list(sizes)
        self.task = task
        self.hidden = hidden
        rng = np.random.default_rng(seed)
        self.W, self.b = [], []
        for i in range(len(self.sizes) - 1):
            scale = np.sqrt(2.0 / (self.sizes[i] + self.sizes[i + 1]))
            self.W.append(rng.normal(0.0, scale, (self.sizes[i], self.sizes[i + 1])))
            self.b.append(np.zeros(self.sizes[i + 1]))
        self.mu = np.zeros(self.sizes[0])
        self.sd = np.ones(self.sizes[0])
        self.y_mu = np.zeros(self.sizes[-1])
        self.y_sd = np.ones(self.sizes[-1])
        self.loss_history: list[float] = []

    # ------------------------------------------------------------------ maths
    def _act(self, z):
        return np.tanh(z) if self.hidden == "tanh" else np.maximum(0.0, z)

    def _dact(self, a):
        return 1.0 - a * a if self.hidden == "tanh" else (a > 0).astype(float)

    def _forward(self, Xn):
        acts = [Xn]
        a = Xn
        last = len(self.W) - 1
        for i, (W, b) in enumerate(zip(self.W, self.b)):
            z = a @ W + b
            if i == last:
                if self.task == "classification":
                    z = z - z.max(axis=1, keepdims=True)
                    e = np.exp(z)
                    a = e / e.sum(axis=1, keepdims=True)
                elif self.task == "binary":
                    a = 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))
                else:
                    a = z
            else:
                a = self._act(z)
            acts.append(a)
        return acts

    def _loss(self, out, Y):
        if self.task == "regression":
            return float(np.mean((out - Y) ** 2))
        eps = 1e-9
        if self.task == "binary":
            return float(-np.mean(Y * np.log(out + eps) + (1 - Y) * np.log(1 - out + eps)))
        return float(-np.mean(np.sum(Y * np.log(out + eps), axis=1)))

    # --------------------------------------------------------------- training
    def fit(self, X, y, epochs=100, lr=0.01, batch=64, l2=1e-5, seed=0):
        X = np.asarray(X, dtype=float)
        n = len(X)
        self.mu = X.mean(axis=0)
        self.sd = X.std(axis=0)
        self.sd[self.sd < 1e-8] = 1.0
        Xn = (X - self.mu) / self.sd
        if self.task == "classification":
            Y = np.eye(self.sizes[-1])[np.asarray(y, dtype=int)]
        elif self.task == "binary":
            Y = np.asarray(y, dtype=float).reshape(-1, 1)
        else:
            y = np.asarray(y, dtype=float).reshape(n, -1)
            self.y_mu = y.mean(axis=0)
            self.y_sd = y.std(axis=0)
            self.y_sd[self.y_sd < 1e-8] = 1.0
            Y = (y - self.y_mu) / self.y_sd

        rng = np.random.default_rng(seed)
        L = len(self.W)
        mW = [np.zeros_like(w) for w in self.W]
        vW = [np.zeros_like(w) for w in self.W]
        mb = [np.zeros_like(b) for b in self.b]
        vb = [np.zeros_like(b) for b in self.b]
        b1, b2, eps = 0.9, 0.999, 1e-8
        step = 0
        self.loss_history = []
        for _ in range(epochs):
            idx = rng.permutation(n)
            for s in range(0, n, batch):
                j = idx[s:s + batch]
                acts = self._forward(Xn[j])
                delta = (acts[-1] - Y[j]) / len(j)
                gW = [None] * L
                gb = [None] * L
                for i in reversed(range(L)):
                    gW[i] = acts[i].T @ delta + l2 * self.W[i]
                    gb[i] = delta.sum(axis=0)
                    if i > 0:
                        delta = (delta @ self.W[i].T) * self._dact(acts[i])
                step += 1
                for i in range(L):
                    mW[i] = b1 * mW[i] + (1 - b1) * gW[i]
                    vW[i] = b2 * vW[i] + (1 - b2) * gW[i] ** 2
                    mb[i] = b1 * mb[i] + (1 - b1) * gb[i]
                    vb[i] = b2 * vb[i] + (1 - b2) * gb[i] ** 2
                    c1, c2 = 1 - b1 ** step, 1 - b2 ** step
                    self.W[i] -= lr * (mW[i] / c1) / (np.sqrt(vW[i] / c2) + eps)
                    self.b[i] -= lr * (mb[i] / c1) / (np.sqrt(vb[i] / c2) + eps)
            self.loss_history.append(self._loss(self._forward(Xn)[-1], Y))
        return self

    # -------------------------------------------------------------- inference
    def predict(self, X):
        X = np.atleast_2d(np.asarray(X, dtype=float))
        out = self._forward((X - self.mu) / self.sd)[-1]
        if self.task == "regression":
            out = out * self.y_sd + self.y_mu
            return out[:, 0] if out.shape[1] == 1 else out
        if self.task == "binary":
            return out[:, 0]
        return out

    def predict_class(self, X):
        return self.predict(X).argmax(axis=1)

    # ------------------------------------------------------------ persistence
    def to_dict(self):
        return {
            "sizes": self.sizes, "task": self.task, "hidden": self.hidden,
            "W": [w.tolist() for w in self.W], "b": [b.tolist() for b in self.b],
            "mu": self.mu.tolist(), "sd": self.sd.tolist(),
            "y_mu": self.y_mu.tolist(), "y_sd": self.y_sd.tolist(),
            "loss_history": [float(v) for v in self.loss_history],
        }

    @classmethod
    def from_dict(cls, d):
        m = cls(d["sizes"], d["task"], d["hidden"])
        m.W = [np.array(w, dtype=float) for w in d["W"]]
        m.b = [np.array(b, dtype=float) for b in d["b"]]
        m.mu = np.array(d["mu"], dtype=float)
        m.sd = np.array(d["sd"], dtype=float)
        m.y_mu = np.array(d["y_mu"], dtype=float)
        m.y_sd = np.array(d["y_sd"], dtype=float)
        m.loss_history = list(d.get("loss_history", []))
        return m


def load_or_train(path, version, train_fn, retrain=False):
    """Load a cached model when its version matches, otherwise train and cache it.

    train_fn() must return (MLP, metrics_dict) where metrics_dict is JSON-serialisable.
    """
    path = Path(path)
    if path.exists() and not retrain:
        try:
            blob = json.loads(path.read_text(encoding="utf-8"))
            if blob.get("version") == version:
                return MLP.from_dict(blob["model"]), blob.get("metrics", {})
        except (ValueError, KeyError, OSError):
            pass
    model, metrics = train_fn()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps({"version": version, "metrics": metrics, "model": model.to_dict()}),
            encoding="utf-8",
        )
    except OSError:
        pass
    return model, metrics
