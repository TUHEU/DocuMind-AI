"""Builds (or loads) every model and exposes the domain objects in one place."""
from __future__ import annotations

from pathlib import Path

from assistant import Assistant
from domains.career import CareerAdvisor
from domains.health import HealthTriage
from domains.queue_sim import QueueDesk
from domains.trip import TrafficModel, TripPlanner

MODEL_DIR = Path(__file__).resolve().parent / "models"


class Hub:
    def __init__(self, model_dir=MODEL_DIR, retrain=False):
        self.traffic = TrafficModel.build(model_dir, retrain)
        self.trip = TripPlanner(self.traffic)
        self.career = CareerAdvisor.build(model_dir, retrain)
        self.health = HealthTriage.build(model_dir, self.trip, retrain)
        self.queue = QueueDesk.build(model_dir, retrain)
        self.assistant = Assistant.build(self, model_dir, retrain)

    def model_report(self):
        """Metrics of every trained network, for the Models tab."""
        def slim(d):
            return {k: v for k, v in d.items() if k not in ("vocab", "intents", "questions", "linear_scorer")}
        return {
            "traffic": slim(self.traffic.metrics),
            "career": {**slim(self.career.metrics), "linear_scorer": self.career.metrics.get("linear_scorer")},
            "health": {**slim(self.health.metrics), "questions": self.health.metrics["questions"]},
            "queue": slim(self.queue.metrics),
            "assistant": slim(self.assistant.metrics),
        }
