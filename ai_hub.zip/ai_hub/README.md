# AI Hub

One local web app that combines three kinds of AI across four domains.
Everything runs offline on your machine. The backend is FastAPI, served by uvicorn;
the neural networks are written from scratch with NumPy (no ML framework).

## Run it

```
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000. The first start trains five small neural networks
(about 10 seconds) and caches them in `models/`. Later starts take about a second.

Optional settings (environment variables): `PORT=5000`, `HOST=0.0.0.0` (to reach it from a phone
on the same network), `RETRAIN=1` (retrain every model, for example after editing the data files).

On Windows PowerShell: `$env:PORT=5001; python app.py`

## Test it

```
python -m unittest discover -s tests -v
```

37 tests, about 15 seconds. They check the algorithms against independent answers
(Floyd-Warshall for routes, exhaustive search for stop order, breadth-first search for grid paths),
the safety rules, the assistant, and every API endpoint including error cases.

## What is inside

| | Search (A*) | Optimisation (GA / PSO) | Neural network |
|---|---|---|---|
| **Trips in Yaounde** | fastest or shortest route on a road graph | GA orders a multi-stop trip; PSO picks the best departure time | predicts the traffic factor from hour, rain and weekend |
| **Career** | cheapest order to learn a role's skills (related skills make learning cheaper) | GA chooses skills to study within a weekly budget; PSO fits a plain weighted scorer used for comparison | scores the chance of being shortlisted for each job |
| **Symptom check** | nearest suitable hospital or clinic | PSO tunes thresholds so missing a serious case costs 4x more than an extra visit; GA finds the questions that matter most | classifies urgency: self-care, clinic or emergency |
| **Service desk queue** | walking route across a campus map | GA orders waiting tickets across counters; PSO tunes the live dispatch rule | predicts how long each ticket takes |

The **Assistant** tab ties them together: a neural network reads what you typed (English or French),
an extractor finds places, skills, symptoms and numbers, and the right module answers.
It remembers skills, symptoms and your location during the conversation.

## Read this before trusting any output

- **The data is sample data.** Traffic patterns, job postings, symptom rules and service times are
  synthetic. Place coordinates are approximate, and the hospitals and clinics are labelled "(sample)".
  The road graph joins each place to its nearest neighbours, so it is a simplification of real roads.
  Replace `data/yaounde.json` and `data/career.json` with verified data, then run with `RETRAIN=1`.
- **The symptom check is an educational demo, not medical advice.** Warning signs (chest pain,
  severe breathing difficulty, confusion or fainting, heavy bleeding, stiff neck with fever) always
  give "emergency" and skip the model. The model itself is trained on rule-generated cases, so it
  only shows how the pipeline works. A real system needs clinician-validated data and review.
- Test results show the algorithms are correct on this data. They do not show the advice is right for real life.

## Layout

```
app.py            FastAPI app and JSON API (run with uvicorn)
hub.py            builds and loads all models
assistant.py      intent network, entity extraction, chat handlers
core/             nn.py (MLP + Adam), search.py (A*), optimize.py (GA, PSO), text.py
domains/          trip.py, career.py, health.py, queue_sim.py
data/             yaounde.json, career.json
static/, templates/   the web interface (no external files or CDNs)
tests/test_all.py
models/           trained networks are cached here
```

## API in one glance

`POST /api/chat`, `/api/trip/route`, `/api/trip/plan`, `/api/trip/departure`,
`/api/career/path`, `/api/career/plan`, `/api/career/match`, `/api/health/triage`,
`/api/health/questions`, `/api/queue/recommend`, `/api/queue/schedule`, `/api/queue/tune`,
and `GET /api/meta`, `/api/models`. Bad input returns HTTP 400 with `{"error": "..."}`.
