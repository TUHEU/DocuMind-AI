"""Campus service desk queue.

* ANN  - predicts how long a ticket will take at a counter.
* A*   - walking route across a campus grid to a counter.
* GA   - order/assignment of waiting tickets to counters to cut weighted waiting.
* PSO  - tunes the weights of the live dispatch rule (wait, priority, duration).
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np

from core.nn import MLP, load_or_train
from core.optimize import ga_permutation, pso
from core.search import astar

SERVICES = ["registration", "payments", "transcripts", "advising"]
BASE_MINUTES = {"registration": 6.0, "payments": 4.0, "transcripts": 9.0, "advising": 12.0}
COUNTERS = [
    {"id": "C1", "services": ["registration", "payments"], "cell": (4, 3)},
    {"id": "C2", "services": ["registration", "transcripts"], "cell": (4, 20)},
    {"id": "C3", "services": ["payments", "advising"], "cell": (8, 11)},
    {"id": "C4", "services": ["transcripts", "advising"], "cell": (11, 21)},
]
ROWS, COLS = 12, 24
BLOCKS = [(1, 1, 3, 4), (1, 7, 3, 10), (1, 13, 3, 16), (1, 19, 3, 22), (5, 2, 7, 7),
          (5, 14, 7, 19), (9, 1, 10, 3), (9, 6, 10, 9), (9, 12, 10, 15), (9, 18, 10, 20)]
CELL_METRES = 15.0
WALK_M_PER_MIN = 80.0
DEFAULT_QUEUE = {"C1": 3, "C2": 1, "C3": 5, "C4": 2}


def _grid():
    wall = np.zeros((ROWS, COLS), dtype=bool)
    for r1, c1, r2, c2 in BLOCKS:
        wall[r1:r2 + 1, c1:c2 + 1] = True
    return wall


WALL = _grid()


def _peak(hour):
    return 1.2 if (9 <= hour < 11.5 or 14 <= hour < 15.5) else 1.0


def true_duration(service, hour, qlen, rng):
    """Synthetic ground truth: service time in minutes."""
    return (BASE_MINUTES[service] * (1 + 0.03 * qlen) * _peak(hour)
            * float(np.exp(rng.normal(0, 0.25))))


def duration_features(service, hour, qlen, priority):
    v = np.zeros(8)
    v[SERVICES.index(service)] = 1.0
    v[4] = math.sin(2 * math.pi * hour / 24)
    v[5] = math.cos(2 * math.pi * hour / 24)
    v[6] = qlen
    v[7] = priority
    return v


class QueueDesk:
    VERSION = "queue-v1"

    def __init__(self, mlp, metrics):
        self.mlp = mlp
        self.metrics = metrics
        self._tuned = None

    @classmethod
    def build(cls, model_dir, retrain=False):
        def train():
            rng = np.random.default_rng(31)
            n = 6000
            X, y = [], []
            for _ in range(n):
                s = SERVICES[rng.integers(4)]
                h, q, pr = rng.uniform(8, 17), int(rng.integers(0, 15)), int(rng.integers(1, 4))
                X.append(duration_features(s, h, q, pr))
                y.append(true_duration(s, h, q, rng))
            X, y = np.array(X), np.array(y)
            mlp = MLP([8, 16, 8, 1], "regression", "tanh", seed=3)
            mlp.fit(X[:5000], y[:5000], epochs=60, lr=0.01, batch=64)
            pred = mlp.predict(X[5000:])
            mae = float(np.mean(np.abs(pred - y[5000:])))
            naive = float(np.mean(np.abs(y[5000:].mean() - y[5000:])))
            return mlp, {
                "task": "regression", "architecture": "8-16-8-1 tanh", "samples": 5000,
                "mae_minutes": round(mae, 3), "mae_minutes_mean_baseline": round(naive, 3),
                "note": "Trained on synthetic service times; replace with real ticket logs.",
            }
        mlp, metrics = load_or_train(Path(model_dir) / "queue.json", cls.VERSION, train, retrain)
        return cls(mlp, metrics)

    # ------------------------------------------------------------- prediction
    def predict_duration(self, service, hour=10.0, qlen=5, priority=1):
        if service not in SERVICES:
            raise ValueError(f"Unknown service: {service}")
        return max(1.0, float(self.mlp.predict(duration_features(service, hour, qlen, priority))[0]))

    def public_meta(self):
        return {"services": SERVICES, "counters": COUNTERS, "rows": ROWS, "cols": COLS,
                "walls": [[int(r), int(c)] for r, c in zip(*np.nonzero(WALL))],
                "default_queue": DEFAULT_QUEUE, "entrance": [0, 0]}

    # ------------------------------------------------------- A*: walking route
    @staticmethod
    def walk(start, goal):
        start, goal = tuple(start), tuple(goal)
        for r, c in (start, goal):
            if not (0 <= r < ROWS and 0 <= c < COLS) or WALL[r, c]:
                raise ValueError(f"Cell {(r, c)} is not walkable.")

        def neighbors(cell):
            r, c = cell
            for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nr, nc = r + dr, c + dc
                if 0 <= nr < ROWS and 0 <= nc < COLS and not WALL[nr, nc]:
                    yield (nr, nc), 1.0, None

        res = astar(start, lambda s: s == goal, neighbors,
                    lambda s: abs(s[0] - goal[0]) + abs(s[1] - goal[1]))
        ref = astar(start, lambda s: s == goal, neighbors)
        steps = res["cost"]
        return {"path": [list(p) for p in res["path"]], "steps": int(steps),
                "minutes": round(steps * CELL_METRES / WALK_M_PER_MIN, 2),
                "expanded_astar": res["expanded"], "expanded_dijkstra": ref["expanded"]}

    def recommend(self, service, cell=(0, 0), queue=None, hour=10.0, priority=1):
        if service not in SERVICES:
            raise ValueError(f"Unknown service: {service}")
        queue = {**DEFAULT_QUEUE, **(queue or {})}
        options = []
        for c in COUNTERS:
            if service not in c["services"]:
                continue
            w = self.walk(cell, c["cell"])
            qlen = int(queue.get(c["id"], 0))
            per_ticket = self.predict_duration(service, hour, qlen, priority)
            wait = qlen * per_ticket
            options.append({"counter": c["id"], "queue_length": qlen,
                            "walk_minutes": w["minutes"], "wait_minutes": round(wait, 1),
                            "total_minutes": round(w["minutes"] + wait, 1),
                            "per_ticket_minutes": round(per_ticket, 1), "walk": w})
        options.sort(key=lambda o: o["total_minutes"])
        return {"service": service, "best": options[0], "options": options}

    # ----------------------------------------------------------- GA scheduling
    @staticmethod
    def _decode(perm, tickets, durations, busy):
        """List scheduling: next ticket goes to the compatible counter that frees first."""
        free = list(busy)
        plan = []
        cost = 0.0
        for i in perm:
            t = tickets[i]
            options = [k for k, c in enumerate(COUNTERS) if t["service"] in c["services"]]
            k = min(options, key=lambda j: (free[j], j))
            start = free[k]
            free[k] = start + durations[i]
            wait = start + t["waited"]
            cost += t["priority"] * wait
            plan.append({"ticket": t["id"], "counter": COUNTERS[k]["id"], "start": round(start, 1),
                         "end": round(free[k], 1), "wait": round(wait, 1),
                         "priority": t["priority"], "service": t["service"]})
        return cost, plan

    def demo_tickets(self, n=10, seed=1):
        rng = np.random.default_rng(seed)
        return [{"id": f"T{i + 1:02d}", "service": SERVICES[int(rng.integers(4))],
                 "priority": int(rng.choice([1, 2, 3], p=[0.6, 0.3, 0.1])),
                 "waited": float(rng.integers(0, 25))} for i in range(n)]

    def schedule(self, tickets, hour=10.0, busy=None, seed=0):
        if not tickets:
            raise ValueError("Add at least one ticket.")
        for t in tickets:
            if t["service"] not in SERVICES:
                raise ValueError(f"Unknown service: {t['service']}")
            t.setdefault("waited", 0.0)
            t.setdefault("priority", 1)
        busy = [float((busy or {}).get(c["id"], 0.0)) for c in COUNTERS]
        n = len(tickets)
        durations = [self.predict_duration(t["service"], hour, n, t["priority"]) for t in tickets]
        fifo = sorted(range(n), key=lambda i: -tickets[i]["waited"])
        wspt = sorted(range(n), key=lambda i: durations[i] / tickets[i]["priority"])
        cost_of = lambda perm: self._decode(perm, tickets, durations, busy)[0]
        ga = ga_permutation(n, cost_of, pop_size=60, generations=80, seed=seed, seeds=[fifo, wspt])
        cost, plan = self._decode(ga["best"], tickets, durations, busy)
        fifo_cost, wspt_cost = cost_of(fifo), cost_of(wspt)
        weights = sum(t["priority"] for t in tickets)
        step = max(1, len(ga["history"]) // 40)
        return {
            "plan": plan, "weighted_wait_ga": round(cost / weights, 2),
            "weighted_wait_fifo": round(fifo_cost / weights, 2),
            "weighted_wait_wspt": round(wspt_cost / weights, 2),
            "improvement_vs_fifo_pct": round(100 * (fifo_cost - cost) / fifo_cost, 1) if fifo_cost else 0.0,
            "history": [round(v / weights, 2) for v in ga["history"][::step]],
            "evaluations": ga["evaluations"],
        }

    # ---------------------------------------------------- PSO: dispatch weights
    def _scenario(self, rng, n=40, horizon=90.0):
        arr = np.sort(rng.uniform(0, horizon, n))
        services = [SERVICES[i] for i in rng.choice(4, n, p=[0.35, 0.25, 0.2, 0.2])]
        prios = rng.choice([1, 2, 3], n, p=[0.6, 0.3, 0.1])
        preds = [self.predict_duration(s, 10.0, 5, int(p)) for s, p in zip(services, prios)]
        truth = [true_duration(s, 10.0, 5, rng) for s in services]
        return [{"arrival": float(a), "service": s, "priority": int(p), "pred": pr, "true": tr}
                for a, s, p, pr, tr in zip(arr, services, prios, preds, truth)]

    @staticmethod
    def simulate(tickets, params):
        alpha, beta, gamma = params
        free = [0.0] * len(COUNTERS)
        remaining = list(range(len(tickets)))
        waits = {}
        while remaining:
            best = None
            for k, c in enumerate(COUNTERS):
                comp = [i for i in remaining if tickets[i]["service"] in c["services"]]
                if not comp:
                    continue
                t = max(free[k], min(tickets[i]["arrival"] for i in comp))
                if best is None or t < best[0]:
                    best = (t, k)
            t, k = best
            avail = [i for i in remaining if tickets[i]["service"] in COUNTERS[k]["services"]
                     and tickets[i]["arrival"] <= t]
            pick = max(avail, key=lambda i: (alpha * (t - tickets[i]["arrival"])
                                             + beta * tickets[i]["priority"]
                                             - gamma * tickets[i]["pred"], -i))
            waits[pick] = t - tickets[pick]["arrival"]
            free[k] = t + tickets[pick]["true"]
            remaining.remove(pick)
        return waits

    def _objective(self, scenarios, params):
        total = 0.0
        for sc in scenarios:
            waits = self.simulate(sc, params)
            w = sum(sc[i]["priority"] * waits[i] for i in waits) / sum(t["priority"] for t in sc)
            total += w + 0.15 * max(waits.values())
        return total / len(scenarios)

    def tune_dispatch(self, seed=0, force=False):
        if self._tuned is not None and not force:
            return self._tuned
        rng = np.random.default_rng(100 + seed)
        train = [self._scenario(rng, n=48) for _ in range(6)]
        test = [self._scenario(rng, n=48) for _ in range(8)]
        fifo = (1.0, 0.0, 0.0)
        res = pso(lambda x: self._objective(train, tuple(x)),
                  [(0.0, 3.0), (0.0, 10.0), (0.0, 3.0)], particles=20, iters=25, seed=seed)
        tuned = tuple(res["x"])
        self._tuned = {
            "params": {"wait_weight": round(tuned[0], 3), "priority_weight": round(tuned[1], 3),
                       "duration_weight": round(tuned[2], 3)},
            "objective_fifo": round(self._objective(test, fifo), 2),
            "objective_tuned": round(self._objective(test, tuned), 2),
            "train_objective_fifo": round(self._objective(train, fifo), 2),
            "train_objective_tuned": round(res["f"], 2),
            "history": [round(v, 2) for v in res["history"]],
            "evaluations": res["evaluations"],
            "note": "Objective = weighted mean wait + 0.15 x longest wait, in minutes, on simulated days.",
        }
        return self._tuned
