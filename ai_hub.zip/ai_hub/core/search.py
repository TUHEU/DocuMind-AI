"""Generic A* search. With no heuristic it behaves as Dijkstra's algorithm."""
from __future__ import annotations

import heapq
import itertools
import math


def astar(start, is_goal, neighbors, heuristic=None):
    """Find a least-cost path.

    neighbors(state) -> iterable of (next_state, cost, action)
    heuristic(state) -> lower bound on remaining cost (must be consistent for optimality)

    Returns None if no goal is reachable, otherwise a dict with
    path (states), actions (one per step), cost and expanded (nodes expanded).
    """
    h = heuristic or (lambda s: 0.0)
    tie = itertools.count()
    frontier = [(h(start), next(tie), 0.0, start)]
    best = {start: 0.0}
    parent = {start: (None, None)}
    closed = set()
    expanded = 0
    while frontier:
        _, _, g, state = heapq.heappop(frontier)
        if state in closed:
            continue
        closed.add(state)
        expanded += 1
        if is_goal(state):
            path, actions = [], []
            cur = state
            while cur is not None:
                prev, act = parent[cur]
                path.append(cur)
                actions.append(act)
                cur = prev
            path.reverse()
            actions.reverse()
            return {"path": path, "actions": actions[1:], "cost": g, "expanded": expanded}
        for nxt, cost, action in neighbors(state):
            new_g = g + cost
            if new_g < best.get(nxt, math.inf):
                best[nxt] = new_g
                parent[nxt] = (state, action)
                heapq.heappush(frontier, (new_g + h(nxt), next(tie), new_g, nxt))
    return None
