"use strict";

/* ------------------------------------------------------------------ helpers */
const NS = "http://www.w3.org/2000/svg";
let META = null;
let CHAT_CTX = {};
const QUEUE = { cell: [0, 0] };

function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === "class") e.className = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v === true ? "" : v);
  }
  append(e, kids);
  return e;
}
function s(tag, attrs, ...kids) {
  const e = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (v != null) e.setAttribute(k, v);
  }
  append(e, kids);
  return e;
}
function append(e, kids) {
  for (const c of kids.flat(Infinity)) {
    if (c == null || c === false) continue;
    e.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
}
const $ = (sel) => document.querySelector(sel);
const fmtHour = (x) => {
  const m = Math.round((((x % 24) + 24) % 24) * 60);
  return String(Math.floor(m / 60) % 24).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0");
};
const num = (x, d = 1) => Number(x).toFixed(d).replace(/\.0+$/, "");
const placeName = (id) => (META.places.find((p) => p.id === id) || {}).name || id;
const skillName = (id) => (META.career.skills.find((k) => k.id === id) || {}).name || id;

async function api(path, body) {
  const res = await fetch(path, {
    method: body === undefined ? "GET" : "POST",
    headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json = {};
  try { json = await res.json(); } catch (e) { json = { error: "The server sent an unreadable answer." }; }
  if (!res.ok) throw new Error(json.error || res.statusText);
  return json;
}

/* Run an async action while the buttons of a form are disabled; show errors in `box`. */
async function run(scope, box, fn) {
  const buttons = scope.querySelectorAll("button");
  buttons.forEach((b) => (b.disabled = true));
  box.setAttribute("aria-busy", "true");
  try {
    await fn();
  } catch (err) {
    box.replaceChildren(h("p", { class: "error", role: "alert" }, err.message));
  } finally {
    buttons.forEach((b) => (b.disabled = false));
    box.removeAttribute("aria-busy");
  }
}

function chipGroup(container, items, initial = []) {
  const selected = new Set(initial);
  container.replaceChildren();
  for (const it of items) {
    const b = h("button", { type: "button", class: "chip", "aria-pressed": String(selected.has(it.id)) }, it.label);
    b.addEventListener("click", () => {
      if (selected.has(it.id)) selected.delete(it.id); else selected.add(it.id);
      b.setAttribute("aria-pressed", String(selected.has(it.id)));
    });
    container.append(b);
  }
  return () => [...selected];
}

function fill(select, options, value) {
  select.replaceChildren();
  for (const o of options) {
    if (o.group) {
      const g = h("optgroup", { label: o.group });
      o.items.forEach((i) => g.append(h("option", { value: i.id }, i.name)));
      select.append(g);
    } else select.append(h("option", { value: o.id }, o.name));
  }
  if (value !== undefined) select.value = value;
}

function facts(pairs) {
  return h("dl", { class: "facts" }, pairs.map(([k, v]) => h("div", null, h("dt", null, k), h("dd", null, v))));
}
function hood(kind, label, text) {
  return h("div", { class: "hood " + kind }, h("b", null, label + ": "), text);
}
function sparkline(values, color = "#2b45b5", label = "") {
  const W = 320, H = 70, p = 8;
  if (!values || values.length < 2) return h("span");
  const lo = Math.min(...values), hi = Math.max(...values);
  const span = hi - lo || 1;
  const pts = values.map((v, i) => `${p + (i * (W - 2 * p)) / (values.length - 1)},${H - p - ((v - lo) / span) * (H - 2 * p)}`);
  return h("div", null,
    s("svg", { class: "chart", viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": label },
      s("polyline", { points: pts.join(" "), fill: "none", stroke: color, "stroke-width": 2.5, "stroke-linejoin": "round" })),
    label ? h("span", { class: "small" }, label) : null);
}

/* --------------------------------------------------------------------- map */
function mapEl(pathIds, opts = {}) {
  const P = META.places;
  const lat0 = Math.max(...P.map((p) => p.lat)), lon0 = Math.min(...P.map((p) => p.lon));
  const kx = 111.32 * Math.cos((lat0 * Math.PI) / 180), ky = 110.57;
  const pos = {};
  P.forEach((p) => (pos[p.id] = [(p.lon - lon0) * kx, (lat0 - p.lat) * ky]));
  const xs = Object.values(pos).map((v) => v[0]), ys = Object.values(pos).map((v) => v[1]);
  const pad = 1.6, W = Math.max(...xs) + 2 * pad, Hh = Math.max(...ys) + 2 * pad;
  const sc = 520 / W;
  const X = (id) => (pos[id][0] + pad) * sc, Y = (id) => (pos[id][1] + pad) * sc;
  const onPath = new Set([...(pathIds || []), ...(opts.stops || [])]);
  const svg = s("svg", { class: "map", viewBox: `0 0 520 ${Math.round(Hh * sc)}`, role: "img",
    "aria-label": "Map of Yaounde with the route highlighted" });
  META.edges.forEach(([a, b]) => svg.append(s("line", { class: "edge", x1: X(a), y1: Y(a), x2: X(b), y2: Y(b) })));
  let route = null;
  if (pathIds && pathIds.length > 1) {
    route = s("polyline", { class: "route", points: pathIds.map((i) => `${X(i)},${Y(i)}`).join(" ") });
    svg.append(route);
  }
  P.forEach((p) => {
    if (p.type === "landmark") svg.append(s("circle", { class: "node", cx: X(p.id), cy: Y(p.id), r: onPath.has(p.id) ? 5 : 3.5 }));
    else svg.append(s("rect", { class: "fac" + (p.type === "hospital" ? " hosp" : ""), x: X(p.id) - 4, y: Y(p.id) - 4, width: 8, height: 8, rx: 2 }));
    if (p.type === "landmark" || onPath.has(p.id)) {
      svg.append(s("text", { class: onPath.has(p.id) ? "on" : "", x: X(p.id) + 7, y: Y(p.id) + 3 }, p.name.replace(" (sample)", "")));
    }
  });
  (opts.stops || []).forEach((id, i) => {
    svg.append(s("circle", { class: "stop", cx: X(id), cy: Y(id), r: 8 }));
    svg.append(s("text", { class: "stopnum", x: X(id), y: Y(id) + 3.5 }, String(i)));
  });
  if (route) requestAnimationFrame(() => {
    try { route.style.setProperty("--len", route.getTotalLength()); route.classList.add("draw"); } catch (e) { /* ignore */ }
  });
  return svg;
}

/* ------------------------------------------------------------ result views */
function routeView(r) {
  return [
    h("div", { class: "headline" }, `${Math.round(r.minutes)} min`,
      h("span", { class: "sub" }, `${r.km} km, leaving ${r.time}${r.rain ? ", raining" : ""}${r.weekend ? ", weekend" : ""}`)),
    mapEl(r.path),
    h("p", { class: "small" }, r.names.join("  →  ")),
    facts([["Free-flow time", `${num(r.free_flow_minutes)} min`], ["Traffic factor", `x${num(r.multiplier, 2)}`]]),
    r.expanded_dijkstra != null ? hood("", "A*", `looked at ${r.expanded_astar} places; plain Dijkstra needed ${r.expanded_dijkstra}.`) : null,
    hood("nn", "Neural network", `predicted the traffic factor for ${r.time}${r.rain ? " in rain" : ""}.`),
  ];
}
function planView(p) {
  const path = p.legs.flatMap((l, i) => (i === 0 ? l.path : l.path.slice(1)));
  return [
    h("div", { class: "headline" }, `${Math.round(p.total_minutes)} min`,
      h("span", { class: "sub" }, p.saved_minutes > 0.5 ? `${Math.round(p.saved_minutes)} min less than your order` : "your order was already the best")),
    mapEl(path, { stops: p.order }),
    h("ol", { class: "steps" }, p.legs.map((l, i) => h("li", null, h("span", { class: "n" }, i + 1),
      h("span", null, `${l.from_name} → ${l.to_name}`), h("span", { class: "small" }, `${Math.round(l.minutes)} min`)))),
    hood("ga", "Genetic algorithm", `tried ${p.evaluations} orders. ` +
      (p.optimal_minutes != null ? `Exhaustive check: best possible is ${num(p.optimal_minutes)} min, GA found ${num(p.total_minutes)} min. ` : "") +
      `Greedy nearest-stop order: ${num(p.greedy_minutes)} min.`),
    sparkline(p.history, "#c98a00", "Best trip time by generation"),
  ];
}
function departureView(d) {
  const W = 560, H = 190, pl = 40, pb = 26, pt = 12, pr = 12;
  const hs = d.profile.map((x) => x.hour), ms = d.profile.map((x) => x.minutes);
  const x0 = Math.min(...hs), x1 = Math.max(...hs), y1 = Math.max(...ms) * 1.1, y0 = 0;
  const X = (v) => pl + ((v - x0) / (x1 - x0 || 1)) * (W - pl - pr);
  const Y = (v) => H - pb - ((v - y0) / (y1 - y0)) * (H - pb - pt);
  const svg = s("svg", { class: "chart", viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Trip time by departure hour" });
  svg.append(s("polyline", { points: d.profile.map((p) => `${X(p.hour)},${Y(p.minutes)}`).join(" "), fill: "none", stroke: "#2b45b5", "stroke-width": 2.5 }));
  d.profile.forEach((p) => {
    if (p.hour % 3 === 0) svg.append(s("text", { x: X(p.hour), y: H - 8, "text-anchor": "middle", "font-size": 11, fill: "#55665f" }, fmtHour(p.hour)));
  });
  [0, y1 / 2, y1].forEach((v) => svg.append(s("text", { x: 4, y: Y(v) + 4, "font-size": 11, fill: "#55665f" }, Math.round(v))));
  svg.append(s("circle", { cx: X(d.best_hour), cy: Y(d.best_minutes), r: 6, fill: "#2f8f5b", stroke: "#16211f" }));
  return [
    h("div", { class: "headline" }, d.best_time, h("span", { class: "sub" }, `is the best time to leave: ${num(d.best_minutes)} min for ${d.km} km`)),
    svg,
    h("p", { class: "small" }, "Minutes on the road by departure hour. The green dot is the swarm's pick."),
    facts([["Best", `${num(d.best_minutes)} min`], ["Worst hour", `${num(d.worst_minutes)} min`], ["Free-flow", `${num(d.free_flow_minutes)} min`]]),
    hood("pso", "Particle swarm", `used ${d.evaluations} evaluations. A 15-minute scan of the whole window agrees: ${d.scan_best_time} (${num(d.scan_best_minutes)} min).`),
    sparkline(d.history, "#2f8f5b", "Best time found by iteration"),
  ];
}
function pathView(p) {
  if (p.already_qualified) return [h("div", { class: "headline" }, "Ready", h("span", { class: "sub" }, `you already have every core skill for ${p.role_name}`))];
  const mx = Math.max(...p.steps.map((x) => x.base_weeks));
  return [
    h("div", { class: "headline" }, `${num(p.total_weeks)} weeks`, h("span", { class: "sub" }, `to become a ${p.role_name.toLowerCase()}`)),
    h("ol", { class: "steps" }, p.steps.map((st, i) => h("li", null, h("span", { class: "n" }, i + 1),
      h("span", null, h("strong", null, st.name), st.required_by_role ? "" : h("span", { class: "small" }, "  (prerequisite)"),
        h("div", { class: "bar" }, h("i", { style: `width:${(st.weeks / mx) * 100}%` }))),
      h("span", { class: "small" }, `${num(st.weeks)}w`, st.discount_pct ? ` (-${st.discount_pct}%)` : "")))),
    h("p", { class: "small" }, "Skills get cheaper to learn when you already know related ones, so the order matters."),
    facts([["This order", `${num(p.total_weeks)} weeks`], ["Naive order", `${num(p.naive_weeks)} weeks`]]),
    hood("", "A*", `searched ${p.expanded_astar} states; plain Dijkstra searched ${p.expanded_dijkstra}.`),
  ];
}
function studyView(p) {
  const gained = p.qualified_after.filter((t) => !p.qualified_before.includes(t));
  return [
    h("div", { class: "headline" }, `${num(p.used_weeks)} of ${num(p.budget_weeks)} weeks`, h("span", { class: "sub" }, "of study planned")),
    p.skills.length ? h("ol", { class: "steps" }, p.skills.map((k, i) => h("li", null, h("span", { class: "n" }, i + 1), h("strong", null, k.name), h("span", { class: "small" }, `${k.weeks}w`))))
      : h("p", { class: "small" }, "Nothing useful fits in that time. Try more weeks."),
    gained.length ? h("p", null, h("strong", null, "Jobs you would qualify for: "), gained.join(", ")) : null,
    h("p", { class: "small" }, "Already qualified for: " + (p.qualified_before.join(", ") || "none yet")),
    hood("ga", "Genetic algorithm", `job-market score ${p.value_ga} versus ${p.value_greedy} for a greedy plan (${p.value_start} before studying). ${p.evaluations} plans tried.`),
    sparkline(p.history, "#c98a00", "Best plan score by generation"),
  ];
}
function matchView(m) {
  return [
    h("ul", { class: "jobs" }, m.matches.map((j) => h("li", null,
      h("div", { class: "top" }, h("strong", null, `${j.title} `, h("span", { class: "small" }, j.city)), h("span", { class: "tag " + j.fit }, `${Math.round(j.probability * 100)}% ${j.fit}`)),
      h("div", { class: "bar" }, h("i", { style: `width:${j.probability * 100}%` })),
      h("span", { class: "small" }, j.missing_names.length ? "Missing: " + j.missing_names.join(", ") : "You have every required skill"),
    ))),
    hood("nn", "Neural network", "estimates the chance of being shortlisted from skill coverage, experience and education."),
    hood("pso", "Particle swarm", "fitted a plain weighted scorer for comparison; its weights: " +
      Object.entries(m.linear_weights).map(([k, v]) => `${k} ${num(v, 2)}`).join(", ") + "."),
  ];
}
function triageView(t) {
  const out = [
    h("div", { class: "level " + t.level }, h("h2", null, t.level_label), h("p", { style: "margin:4px 0 0" }, t.advice)),
    h("p", { class: "small" }, t.reason),
  ];
  if (t.facility) {
    out.push(h("h3", null, `Nearest ${t.level === "emergency" ? "hospital" : "facility"}: ${t.facility.names[t.facility.names.length - 1]}`),
      mapEl(t.facility.path),
      facts([["Travel time", `${Math.round(t.facility.minutes)} min`], ["Distance", `${t.facility.km} km`]]),
      h("p", { class: "small" }, "Other options: " + (t.facility.alternatives || []).slice(1).map((a) => `${a.name} (${Math.round(a.minutes)} min)`).join(", ")),
      hood("", "A*", `found it after expanding ${t.facility.expanded_astar} places.`));
  }
  const pr = t.probabilities;
  out.push(h("div", { class: "hood nn" }, h("b", null, "Neural network: "), `self-care ${Math.round(pr.self_care * 100)}%, clinic ${Math.round(pr.clinic * 100)}%, emergency ${Math.round(pr.emergency * 100)}%. `,
    t.red_flags.length ? "Warning signs skip the model and always mean emergency." : "Thresholds were tuned by particle swarm so missed serious cases cost more than extra visits."));
  out.push(h("p", { class: "small" }, t.disclaimer));
  return out;
}
function questionsView(q) {
  const mx = Math.max(...q.importance.map((i) => i.extra_cost));
  return [
    h("h3", null, "Which questions matter most"),
    h("p", { class: "small" }, "Extra triage cost when a symptom is not asked about. Bigger means more useful."),
    h("ul", { class: "jobs" }, q.importance.map((i) => h("li", null, h("div", { class: "top" }, h("span", null, i.label),
      h("span", { class: "small" }, num(i.extra_cost, 2))), h("div", { class: "bar sun" }, h("i", { style: `width:${(i.extra_cost / mx) * 100}%` }))))),
    hood("ga", "Genetic algorithm", `kept ${q.selected.length} of ${q.importance.length} questions; triage cost ${num(q.cost_selected, 3)} versus ${num(q.cost_all, 3)} with all of them.`),
  ];
}

/* ------------------------------------------------------------------- queue */
function gridSvg(path) {
  const Q = META.queue, C = 22;
  const walls = new Set(Q.walls.map((w) => w.join(",")));
  const svg = s("svg", { class: "chart grid", viewBox: `0 0 ${Q.cols * C} ${Q.rows * C}`, role: "img", "aria-label": "Campus map. Click a free cell to set where you are." });
  for (let r = 0; r < Q.rows; r++) for (let c = 0; c < Q.cols; c++) {
    const wall = walls.has(r + "," + c);
    const rect = s("rect", { class: wall ? "wall" : "cell", x: c * C, y: r * C, width: C, height: C });
    if (!wall) rect.addEventListener("click", () => { QUEUE.cell = [r, c]; redrawGrid(); });
    svg.append(rect);
  }
  if (path && path.length) svg.append(s("polyline", { class: "walk", points: path.map(([r, c]) => `${c * C + C / 2},${r * C + C / 2}`).join(" ") }));
  Q.counters.forEach((k) => {
    svg.append(s("rect", { class: "counter", x: k.cell[1] * C + 2, y: k.cell[0] * C + 2, width: C - 4, height: C - 4, rx: 4 }));
    svg.append(s("text", { x: k.cell[1] * C + C / 2, y: k.cell[0] * C + C / 2 }, k.id));
  });
  svg.append(s("circle", { class: "here", cx: QUEUE.cell[1] * C + C / 2, cy: QUEUE.cell[0] * C + C / 2, r: 7 }));
  return svg;
}
let queuePath = null;
function redrawGrid() {
  const old = $("#queue-grid svg");
  if (old) old.replaceWith(gridSvg(queuePath));
}
function queueBody() {
  const q = {};
  META.queue.counters.forEach((c) => (q[c.id] = Number($("#q-" + c.id).value) || 0));
  return q;
}

/* ------------------------------------------------------------------- panels */
function initTabs() {
  const tabs = document.querySelectorAll(".tab");
  const show = (name) => {
    tabs.forEach((t) => (t.dataset.panel === name ? t.setAttribute("aria-current", "page") : t.removeAttribute("aria-current")));
    document.querySelectorAll(".panel").forEach((p) => (p.hidden = p.id !== "panel-" + name));
    if (name === "models") loadModels();
    history.replaceState(null, "", "#" + name);
  };
  tabs.forEach((t) => t.addEventListener("click", () => show(t.dataset.panel)));
  const start = location.hash.slice(1);
  show(["chat", "trip", "career", "health", "queue", "models"].includes(start) ? start : "chat");
}

function initChat() {
  const log = $("#chat-log"), form = $("#chat-form"), input = $("#chat-input");
  const add = (cls, text, extra) => {
    const m = h("div", { class: "msg " + cls }, text, extra || null);
    log.append(m);
    log.scrollTop = log.scrollHeight;
    return m;
  };
  add("bot", "Hi! Ask me about routes in Yaounde, careers, symptoms or service-desk queues. Say \"help\" to see examples.");
  const ex = $("#chat-examples");
  META.examples.forEach((t) => ex.append(h("button", { type: "button", class: "chip", onclick: () => { input.value = t; form.requestSubmit(); } }, t)));

  const showCtx = () => {
    const box = $("#chat-ctx"), c = CHAT_CTX, bits = [];
    if (c.skills && c.skills.length) bits.push("Skills: " + c.skills.map(skillName).join(", "));
    if (c.symptoms && c.symptoms.length) bits.push("Symptoms: " + c.symptoms.map((x) => x.replace(/_/g, " ")).join(", "));
    if (c.location) bits.push("Location: " + placeName(c.location));
    box.hidden = !bits.length;
    box.replaceChildren(...bits.map((b) => h("span", null, b)),
      bits.length ? h("button", { type: "button", onclick: () => { CHAT_CTX = {}; showCtx(); } }, "Forget these") : "");
  };

  form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    input.value = "";
    add("user", text);
    const wait = add("bot", "Thinking...");
    await run(form, wait, async () => {
      const r = await api("/api/chat", { message: text, context: CHAT_CTX });
      CHAT_CTX = r.context || {};
      const extra = [];
      const d = r.data;
      if (d && d.kind === "route") extra.push(mapEl(d.route.path));
      if (d && d.kind === "plan") extra.push(mapEl(d.plan.legs.flatMap((l, i) => (i ? l.path.slice(1) : l.path)), { stops: d.plan.order }));
      if (d && d.kind === "triage" && d.triage.facility) extra.push(mapEl(d.triage.facility.path));
      wait.replaceChildren(r.reply, ...extra, h("span", { class: "meta" }, `Understood as ${r.intent.replace(/_/g, " ")} (${Math.round(r.confidence * 100)}% sure)`));
      log.scrollTop = log.scrollHeight;
      showCtx();
    });
    input.focus();
  });
}

function initTrip() {
  const lands = META.places.filter((p) => p.type === "landmark");
  const facs = META.places.filter((p) => p.type !== "landmark");
  const opts = [{ group: "Places", items: lands }, { group: "Health facilities (sample)", items: facs }];
  fill($("#trip-from"), opts, "bastos");
  fill($("#trip-to"), opts, "mvan");
  const stops = $("#trip-stops");
  lands.forEach((p) => stops.append(h("label", { class: "check" }, h("input", { type: "checkbox", value: p.id }), p.name)));
  const hour = $("#trip-hour"), hv = $("#trip-hour-val");
  const upd = () => (hv.textContent = fmtHour(Number(hour.value)));
  hour.addEventListener("input", upd); upd();
  const box = $("#trip-result"), form = $("#trip-form");
  const common = () => ({ hour: Number(hour.value), rain: $("#trip-rain").checked, weekend: $("#trip-weekend").checked });

  form.addEventListener("submit", (ev) => {
    ev.preventDefault();
    run(form, box, async () => box.replaceChildren(...routeView(await api("/api/trip/route",
      { from: $("#trip-from").value, to: $("#trip-to").value, mode: $("#trip-mode").value, ...common() }))));
  });
  $("#trip-plan-btn").addEventListener("click", () => run(form, box, async () => {
    const chosen = [...stops.querySelectorAll("input:checked")].map((i) => i.value);
    box.replaceChildren(...planView(await api("/api/trip/plan",
      { start: $("#trip-from").value, stops: chosen, round_trip: $("#trip-round").checked, ...common() })));
  }));
  $("#trip-departure-btn").addEventListener("click", () => run(form, box, async () => {
    const c = common();
    box.replaceChildren(...departureView(await api("/api/trip/departure",
      { from: $("#trip-from").value, to: $("#trip-to").value, rain: c.rain, weekend: c.weekend })));
  }));
}

function initCareer() {
  const getSkills = chipGroup($("#career-skills"), META.career.skills.map((k) => ({ id: k.id, label: k.name })));
  fill($("#career-role"), META.career.roles);
  const box = $("#career-result"), form = $("#career-form");
  const base = () => ({ have: getSkills(), years: Number($("#career-years").value) || 0, education: $("#career-edu").value });
  form.addEventListener("submit", (ev) => {
    ev.preventDefault();
    run(form, box, async () => box.replaceChildren(...pathView(await api("/api/career/path", { have: getSkills(), role: $("#career-role").value }))));
  });
  $("#career-plan-btn").addEventListener("click", () => run(form, box, async () =>
    box.replaceChildren(...studyView(await api("/api/career/plan", { have: getSkills(), weeks: Number($("#career-weeks").value) || 8 })))));
  $("#career-match-btn").addEventListener("click", () => run(form, box, async () =>
    box.replaceChildren(...matchView(await api("/api/career/match", base())))));
}

function initHealth() {
  $("#health-notice").textContent = META.health.disclaimer;
  const g1 = chipGroup($("#health-symptoms"), META.health.symptoms);
  const g2 = chipGroup($("#health-red"), META.health.red_flags);
  fill($("#health-age"), META.health.ages.map((a) => ({ id: a, name: a[0].toUpperCase() + a.slice(1) })), "adult");
  const lands = META.places.filter((p) => p.type === "landmark");
  fill($("#health-loc"), [{ id: "", name: "Do not share" }, ...lands], "bastos");
  const box = $("#health-result"), form = $("#health-form");
  form.addEventListener("submit", (ev) => {
    ev.preventDefault();
    run(form, box, async () => box.replaceChildren(...triageView(await api("/api/health/triage", {
      symptoms: [...g1(), ...g2()], age: $("#health-age").value, days: Number($("#health-days").value) || 0,
      location: $("#health-loc").value }))));
  });
  $("#health-q-btn").addEventListener("click", () => run(form, box, async () =>
    box.replaceChildren(...questionsView(await api("/api/health/questions", {})))));
}

function initQueue() {
  fill($("#queue-service"), META.queue.services.map((x) => ({ id: x, name: x[0].toUpperCase() + x.slice(1) })));
  const lens = $("#queue-lens");
  META.queue.counters.forEach((c) => lens.append(h("label", null, `${c.id}`, h("input", { id: "q-" + c.id, type: "number", min: 0, max: 40, value: META.queue.default_queue[c.id] }))));
  const box = $("#queue-result"), form = $("#queue-form");
  const out = h("div", { style: "display:flex;flex-direction:column;gap:14px" });
  const gridBox = h("div", { id: "queue-grid" }, gridSvg(null));
  box.replaceChildren(gridBox, out);
  const view = (...nodes) => out.replaceChildren(...nodes.flat());

  form.addEventListener("submit", (ev) => {
    ev.preventDefault();
    run(form, out, async () => {
      const r = await api("/api/queue/recommend", { service: $("#queue-service").value, cell: QUEUE.cell,
        queue: queueBody(), priority: Number($("#queue-priority").value) });
      queuePath = r.best.walk.path; redrawGrid();
      view(h("div", { class: "headline" }, `Counter ${r.best.counter}`, h("span", { class: "sub" }, `about ${num(r.best.total_minutes)} min in total`)),
        h("div", { class: "tablewrap" }, h("table", null,
          h("thead", null, h("tr", null, ["Counter", "People ahead", "Walk", "Wait", "Total"].map((t) => h("th", null, t)))),
          h("tbody", null, r.options.map((o) => h("tr", null, h("td", null, o.counter), h("td", null, o.queue_length),
            h("td", null, `${num(o.walk_minutes)} min`), h("td", null, `${num(o.wait_minutes)} min`), h("td", null, h("strong", null, `${num(o.total_minutes)} min`))))))),
        hood("", "A*", `walked the campus grid with ${r.best.walk.expanded_astar} cells expanded; plain Dijkstra needed ${r.best.walk.expanded_dijkstra}.`),
        hood("nn", "Neural network", `predicted ${num(r.best.per_ticket_minutes)} min per ticket at this time of day, which turns queue length into waiting time.`));
    });
  });
  $("#queue-schedule-btn").addEventListener("click", () => run(form, out, async () => {
    const r = await api("/api/queue/schedule", {});
    queuePath = null; redrawGrid();
    view(h("div", { class: "headline" }, `${r.improvement_vs_fifo_pct}% less waiting`, h("span", { class: "sub" }, "than first come, first served")),
      facts([["Optimised", `${num(r.weighted_wait_ga)} min`], ["First come first served", `${num(r.weighted_wait_fifo)} min`], ["Shortest job first", `${num(r.weighted_wait_wspt)} min`]]),
      h("p", { class: "small" }, "Average wait weighted by priority, for 10 demo tickets."),
      h("div", { class: "tablewrap" }, h("table", null,
        h("thead", null, h("tr", null, ["Ticket", "Service", "Priority", "Counter", "Starts", "Waits"].map((t) => h("th", null, t)))),
        h("tbody", null, r.plan.map((p) => h("tr", null, h("td", null, p.ticket), h("td", null, p.service), h("td", null, p.priority),
          h("td", null, p.counter), h("td", null, `${num(p.start)} min`), h("td", null, `${num(p.wait)} min`)))))),
      hood("ga", "Genetic algorithm", `searched ${r.evaluations} serving orders, starting from first-come-first-served and shortest-job-first.`),
      sparkline(r.history, "#c98a00", "Average weighted wait by generation"));
  }));
  $("#queue-tune-btn").addEventListener("click", () => run(form, out, async () => {
    out.replaceChildren(h("p", { class: "small" }, "Simulating queue days. This takes a few seconds..."));
    const r = await api("/api/queue/tune", {});
    view(h("div", { class: "headline" }, `${num(r.objective_tuned)} vs ${num(r.objective_fifo)}`, h("span", { class: "sub" }, "score on unseen simulated days (lower is better)")),
      facts([["Weight on waiting time", num(r.params.wait_weight, 2)], ["Weight on priority", num(r.params.priority_weight, 2)], ["Weight on short jobs", num(r.params.duration_weight, 2)]]),
      h("p", { class: "small" }, r.note),
      hood("pso", "Particle swarm", `tested ${r.evaluations} rule settings on simulated days and compared the best against first come, first served on days it had never seen.`),
      sparkline(r.history, "#2f8f5b", "Best score by iteration"));
  }));
}

const MODEL_TITLES = { traffic: "Traffic predictor", career: "Job match scorer", health: "Urgency classifier",
  queue: "Service time predictor", assistant: "Intent classifier" };
let modelsLoaded = false;
async function loadModels() {
  if (modelsLoaded) return;
  const box = $("#models-list");
  try {
    const m = await api("/api/models");
    box.replaceChildren(...Object.entries(m).map(([k, v]) => {
      const rows = [];
      Object.entries(v).forEach(([key, val]) => {
        if (["task", "note", "architecture"].includes(key)) return;
        if (key === "thresholds") { rows.push(["decision thresholds", `${num(val.t1, 2)} / +${num(val.gap, 2)}`]); return; }
        if (typeof val === "object") return;
        rows.push([key.replace(/_/g, " "), typeof val === "number" ? num(val, 4) : String(val)]);
      });
      return h("article", { class: "card" }, h("h2", null, MODEL_TITLES[k] || k), h("p", { class: "small" }, `${v.task}, ${v.architecture}`),
        h("dl", null, rows.map(([a, b]) => [h("dt", null, a), h("dd", null, b)])), h("p", { class: "small" }, v.note || ""));
    }));
    modelsLoaded = true;
  } catch (err) {
    box.replaceChildren(h("p", { class: "error", role: "alert" }, err.message));
  }
}

/* --------------------------------------------------------------------- boot */
(async function boot() {
  try {
    META = await api("/api/meta");
  } catch (err) {
    document.querySelector("main").prepend(h("p", { class: "error", role: "alert" }, "Could not reach the AI Hub server: " + err.message));
    return;
  }
  initTabs(); initChat(); initTrip(); initCareer(); initHealth(); initQueue();
})();
