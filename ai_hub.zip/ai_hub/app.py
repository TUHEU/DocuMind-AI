"""AI Hub - local Flask app.  Run with:  python app.py   then open http://127.0.0.1:5000

Environment variables: HOST (default 127.0.0.1), PORT (default 5000), RETRAIN=1 to retrain all models.
"""
from __future__ import annotations

import datetime
import os

from flask import Flask, jsonify, render_template, request

from hub import Hub


def _num(body, key, default, lo=None, hi=None):
    v = body.get(key, default)
    try:
        v = float(v)
    except (TypeError, ValueError):
        raise ValueError(f"'{key}' must be a number")
    if lo is not None and v < lo or hi is not None and v > hi:
        raise ValueError(f"'{key}' must be between {lo} and {hi}")
    return v


def _hour(body):
    if body.get("hour") is None:
        n = datetime.datetime.now()
        return n.hour + n.minute / 60
    return _num(body, "hour", 12, 0, 24)


def create_app(hub=None):
    app = Flask(__name__)
    app.json.sort_keys = False
    hub = hub or Hub(retrain=os.environ.get("RETRAIN") == "1")
    app.config["HUB"] = hub

    def post(rule, fn):
        def view():
            body = request.get_json(silent=True) or {}
            try:
                return jsonify(fn(body))
            except ValueError as e:
                return jsonify({"error": str(e)}), 400
        view.__name__ = "api_" + rule.strip("/").replace("/", "_")
        app.add_url_rule(rule, view_func=view, methods=["POST"])

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/meta")
    def meta():
        return jsonify({
            "places": hub.trip.public_nodes(), "edges": hub.trip.edges(),
            "career": hub.career.public_meta(), "health": hub.health.public_meta(),
            "queue": hub.queue.public_meta(),
            "examples": ["Fastest way from Bastos to Mvan at 8am",
                         "Best order to visit Mokolo, Essos and Ekounou starting from Bastos",
                         "I know Python and Git", "How do I become a backend developer?",
                         "Which jobs fit me?", "What should I learn in 8 weeks?",
                         "I have fever and cough", "Nearest hospital to Mokolo",
                         "Which counter for registration?", "Optimise the queue"],
        })

    @app.get("/api/models")
    def models():
        return jsonify(hub.model_report())

    # ---- chat
    post("/api/chat", lambda b: hub.assistant.reply(b.get("message"), b.get("context")))

    # ---- trip
    post("/api/trip/route", lambda b: hub.trip.route(
        b.get("from"), b.get("to"), _hour(b), bool(b.get("rain")), bool(b.get("weekend")),
        b.get("mode", "time") if b.get("mode") in ("time", "distance") else "time"))
    post("/api/trip/plan", lambda b: hub.trip.plan_stops(
        b.get("start"), b.get("stops") or [], _hour(b), bool(b.get("rain")), bool(b.get("weekend")),
        bool(b.get("round_trip"))))
    post("/api/trip/departure", lambda b: hub.trip.best_departure(
        b.get("from"), b.get("to"), bool(b.get("rain")), bool(b.get("weekend")),
        _num(b, "earliest", 5, 0, 23), _num(b, "latest", 22, 1, 24)))

    # ---- career
    post("/api/career/path", lambda b: hub.career.learning_path(b.get("have") or [], b.get("role")))
    post("/api/career/plan", lambda b: hub.career.study_plan(
        b.get("have") or [], _num(b, "weeks", 8, 1, 104)))
    post("/api/career/match", lambda b: hub.career.match(
        b.get("have") or [], _num(b, "years", 0, 0, 40),
        b.get("education") if b.get("education") in ("secondary", "bachelor", "master") else "bachelor"))

    # ---- health
    post("/api/health/triage", lambda b: hub.health.triage(
        b.get("symptoms") or [], b.get("age", "adult"), _num(b, "days", 1, 0, 60),
        b.get("location") or None, _hour(b), bool(b.get("rain")), bool(b.get("weekend"))))
    post("/api/health/questions", lambda b: hub.health.questions())

    # ---- queue
    def _cell(b):
        c = b.get("cell") or [0, 0]
        if not (isinstance(c, (list, tuple)) and len(c) == 2):
            raise ValueError("'cell' must be [row, col]")
        return int(c[0]), int(c[1])

    post("/api/queue/recommend", lambda b: hub.queue.recommend(
        b.get("service"), _cell(b), b.get("queue"), _hour(b), int(_num(b, "priority", 1, 1, 3))))
    post("/api/queue/schedule", lambda b: hub.queue.schedule(
        b.get("tickets") or hub.queue.demo_tickets(int(_num(b, "n", 10, 2, 30)), int(_num(b, "seed", 1))),
        _hour(b), b.get("busy")))
    post("/api/queue/tune", lambda b: hub.queue.tune_dispatch())

    return app


if __name__ == "__main__":
    application = create_app()
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "5000"))
    print(f"\n  AI Hub is running -> http://{host if host != '0.0.0.0' else '127.0.0.1'}:{port}\n")
    application.run(host=host, port=port, debug=False, use_reloader=False, threaded=True)
