"""Meta-heuristic optimisers: Genetic Algorithm (permutation / binary) and PSO."""
from __future__ import annotations

import random

import numpy as np


# ------------------------------------------------------------ genetic algorithm
def _order_crossover(p1, p2, rng):
    n = len(p1)
    a, b = sorted(rng.sample(range(n), 2))
    child = [None] * n
    child[a:b + 1] = p1[a:b + 1]
    used = set(child[a:b + 1])
    fill = [g for g in p2 if g not in used]
    it = iter(fill)
    for i in range(n):
        if child[i] is None:
            child[i] = next(it)
    return child


def ga_permutation(n, cost_fn, pop_size=60, generations=120, crossover=0.9,
                   mutation=0.25, elite=2, tournament=3, seed=0, seeds=None):
    """Minimise cost_fn(perm) over permutations of range(n).

    Uses tournament selection, order crossover (OX), swap/inversion mutation and
    elitism. `seeds` are optional starting permutations injected into generation 0.
    """
    rng = random.Random(seed)
    cache: dict = {}

    def cost(p):
        key = tuple(p)
        if key not in cache:
            cache[key] = cost_fn(list(p))
        return cache[key]

    if n <= 1:
        perm = list(range(n))
        return {"best": perm, "cost": cost(perm), "history": [cost(perm)], "evaluations": 1}

    population = [list(s) for s in (seeds or [])]
    while len(population) < pop_size:
        p = list(range(n))
        rng.shuffle(p)
        population.append(p)

    history = []
    for _ in range(generations):
        population.sort(key=cost)
        history.append(cost(population[0]))
        nxt = [p[:] for p in population[:elite]]
        while len(nxt) < pop_size:
            a = min(rng.sample(population, min(tournament, len(population))), key=cost)
            b = min(rng.sample(population, min(tournament, len(population))), key=cost)
            child = _order_crossover(a, b, rng) if rng.random() < crossover else a[:]
            if rng.random() < mutation:
                i, j = sorted(rng.sample(range(n), 2))
                if rng.random() < 0.5:
                    child[i], child[j] = child[j], child[i]
                else:
                    child[i:j + 1] = child[i:j + 1][::-1]
            nxt.append(child)
        population = nxt
    population.sort(key=cost)
    history.append(cost(population[0]))
    return {"best": population[0], "cost": cost(population[0]), "history": history,
            "evaluations": len(cache)}


def ga_binary(n, fitness_fn, pop_size=60, generations=100, crossover=0.9,
              mutation=None, elite=2, tournament=3, seed=0, init_prob=0.25, seeds=None):
    """Maximise fitness_fn(bits) over binary strings of length n."""
    rng = random.Random(seed)
    mutation = mutation if mutation is not None else 1.0 / max(n, 1)
    cache: dict = {}

    def fit(bits):
        key = tuple(bits)
        if key not in cache:
            cache[key] = fitness_fn(list(bits))
        return cache[key]

    population = [list(s) for s in (seeds or [])]
    while len(population) < pop_size:
        population.append([1 if rng.random() < init_prob else 0 for _ in range(n)])

    history = []
    for _ in range(generations):
        population.sort(key=fit, reverse=True)
        history.append(fit(population[0]))
        nxt = [p[:] for p in population[:elite]]
        while len(nxt) < pop_size:
            a = max(rng.sample(population, min(tournament, len(population))), key=fit)
            b = max(rng.sample(population, min(tournament, len(population))), key=fit)
            if rng.random() < crossover:
                child = [x if rng.random() < 0.5 else y for x, y in zip(a, b)]
            else:
                child = a[:]
            child = [1 - g if rng.random() < mutation else g for g in child]
            nxt.append(child)
        population = nxt
    population.sort(key=fit, reverse=True)
    history.append(fit(population[0]))
    return {"best": population[0], "fitness": fit(population[0]), "history": history,
            "evaluations": len(cache)}


# ----------------------------------------------------------------------- PSO
def pso(objective, bounds, particles=20, iters=40, w=0.72, c1=1.49, c2=1.49, seed=0):
    """Minimise objective(x) with x a vector inside `bounds` = [(lo, hi), ...]."""
    rng = np.random.default_rng(seed)
    lo = np.array([b[0] for b in bounds], dtype=float)
    hi = np.array([b[1] for b in bounds], dtype=float)
    span = hi - lo
    dim = len(lo)
    x = rng.uniform(lo, hi, (particles, dim))
    v = rng.uniform(-span, span, (particles, dim)) * 0.1
    pbest = x.copy()
    pf = np.array([objective(p) for p in x], dtype=float)
    evals = particles
    g = int(pf.argmin())
    gbest, gf = pbest[g].copy(), float(pf[g])
    history = [gf]
    for _ in range(iters):
        r1 = rng.random((particles, dim))
        r2 = rng.random((particles, dim))
        v = w * v + c1 * r1 * (pbest - x) + c2 * r2 * (gbest - x)
        v = np.clip(v, -0.25 * span, 0.25 * span)
        x = np.clip(x + v, lo, hi)
        f = np.array([objective(p) for p in x], dtype=float)
        evals += particles
        better = f < pf
        pbest[better] = x[better]
        pf[better] = f[better]
        g = int(pf.argmin())
        if pf[g] < gf:
            gf, gbest = float(pf[g]), pbest[g].copy()
        history.append(gf)
    return {"x": gbest.tolist(), "f": gf, "history": history, "evaluations": evals}
