"""Run with:  python -m unittest discover -s tests -v   (from the project folder)"""
import itertools
import math
import random
import sys
import tempfile
import unittest
from collections import deque
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.nn import MLP, load_or_train                       # noqa: E402
from core.optimize import ga_binary, ga_permutation, pso      # noqa: E402
from core.search import astar                                 # noqa: E402
from assistant import VALIDATION                              # noqa: E402
from domains import queue_sim                                 # noqa: E402
from hub import Hub                                           # noqa: E402
from app import create_app                                    # noqa: E402

HUB = None
CLIENT = None
TMP = None


def setUpModule():
    global HUB, CLIENT, TMP
    TMP = tempfile.TemporaryDirectory()
    HUB = Hub(model_dir=TMP.name, retrain=True)
    CLIENT = create_app(HUB).test_client()


def tearDownModule():
    TMP.cleanup()


# ------------------------------------------------------------------- engines
class TestEngines(unittest.TestCase):
    def test_astar_matches_bruteforce_on_random_graphs(self):
        rng = random.Random(3)
        for _ in range(20):
            n = 9
            pts = [(rng.random(), rng.random()) for _ in range(n)]
            d = lambda a, b: math.dist(pts[a], pts[b])
            adj = {i: [j for j in range(n) if j != i and rng.random() < 0.4] for i in range(n)}
            for i in range(n):
                for j in adj[i]:
                    if i not in adj[j]:
                        adj[j].append(i)
            D = [[math.inf] * n for _ in range(n)]           # Floyd-Warshall reference
            for i in range(n):
                D[i][i] = 0
                for j in adj[i]:
                    D[i][j] = d(i, j)
            for k in range(n):
                for i in range(n):
                    for j in range(n):
                        D[i][j] = min(D[i][j], D[i][k] + D[k][j])
            a, b = 0, n - 1
            res = astar(a, lambda s: s == b, lambda s: [(t, d(s, t), None) for t in adj[s]],
                        lambda s: d(s, b))
            if D[a][b] == math.inf:
                self.assertIsNone(res)
            else:
                self.assertAlmostEqual(res["cost"], D[a][b], places=9)

    def test_ga_permutation_finds_optimum_on_small_tsp(self):
        rng = random.Random(5)
        pts = [(rng.random(), rng.random()) for _ in range(7)]
        cost = lambda p: sum(math.dist(pts[a], pts[b]) for a, b in zip(p, p[1:]))
        best = min(cost(list(p)) for p in itertools.permutations(range(7)))
        res = ga_permutation(7, cost, pop_size=60, generations=60, seed=1)
        self.assertAlmostEqual(res["cost"], best, places=9)
        self.assertEqual(sorted(res["best"]), list(range(7)))

    def test_ga_binary_knapsack_reaches_optimum(self):
        rng = random.Random(2)
        n = 12
        w = [rng.randint(1, 9) for _ in range(n)]
        v = [rng.randint(1, 20) for _ in range(n)]
        cap = 25
        fit = lambda bits: (sum(x * y for x, y in zip(bits, v))
                            if sum(x * y for x, y in zip(bits, w)) <= cap else -1)
        best = max(fit(list(b)) for b in itertools.product([0, 1], repeat=n))
        res = ga_binary(n, fit, pop_size=80, generations=80, seed=4)
        self.assertEqual(res["fitness"], best)

    def test_pso_minimises_shifted_sphere(self):
        res = pso(lambda x: (x[0] - 1.5) ** 2 + (x[1] + 2.0) ** 2, [(-5, 5), (-5, 5)], seed=1)
        self.assertLess(res["f"], 1e-3)

    def test_mlp_regression_and_persistence(self):
        rng = np.random.default_rng(0)
        X = rng.uniform(-2, 2, (1500, 2))
        y = np.sin(X[:, 0]) + X[:, 1] ** 2
        m = MLP([2, 16, 1], "regression", seed=1).fit(X, y, epochs=150, lr=0.01)
        Xt = rng.uniform(-2, 2, (300, 2))
        mae = np.mean(np.abs(m.predict(Xt) - (np.sin(Xt[:, 0]) + Xt[:, 1] ** 2)))
        self.assertLess(mae, 0.15)
        m2 = MLP.from_dict(m.to_dict())
        np.testing.assert_allclose(m.predict(Xt), m2.predict(Xt))

    def test_mlp_classification_and_cache(self):
        rng = np.random.default_rng(1)
        X = rng.normal(0, 1, (900, 2))
        y = (X[:, 0] * X[:, 1] > 0).astype(int)              # XOR-like, not linearly separable
        m = MLP([2, 12, 2], "classification", seed=2).fit(X, y, epochs=80, lr=0.02)
        self.assertGreater(np.mean(m.predict_class(X) == y), 0.95)
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "m.json"
            calls = []

            def train():
                calls.append(1)
                return m, {"acc": 1.0}

            load_or_train(p, "v1", train)
            load_or_train(p, "v1", train)
            self.assertEqual(len(calls), 1)                   # second call loaded the cache
            load_or_train(p, "v2", train)
            self.assertEqual(len(calls), 2)                   # new version retrains


# --------------------------------------------------------------------- trips
class TestTrip(unittest.TestCase):
    def test_graph_is_connected_and_facilities_are_never_transit(self):
        trip = HUB.trip
        seen, stack = set(), [trip.order[0]]
        while stack:
            n = stack.pop()
            if n not in seen:
                seen.add(n)
                stack.extend(trip.adj[n])
        self.assertEqual(seen, set(trip.order))
        for a in trip.nodes:
            for b in trip.nodes:
                if a != b:
                    for mid in trip.route(a, b, 8, compare=False)["path"][1:-1]:
                        self.assertEqual(trip.nodes[mid]["type"], "landmark")

    def test_route_is_optimal_against_floyd_warshall(self):
        trip = HUB.trip
        lands = [i for i in trip.order if trip.nodes[i]["type"] == "landmark"]
        D = {(a, b): (0 if a == b else trip.adj[a].get(b, math.inf)) for a in lands for b in lands}
        for k in lands:
            for a in lands:
                for b in lands:
                    D[a, b] = min(D[a, b], D[a, k] + D[k, b])
        for a, b in itertools.combinations(lands, 2):
            r = trip.route(a, b, 12, mode="distance")
            self.assertAlmostEqual(r["km"], D[a, b], places=1)
            self.assertLessEqual(r["expanded_astar"], r["expanded_dijkstra"])

    def test_traffic_model_shape(self):
        t = HUB.traffic
        self.assertGreater(t.multiplier(8), t.multiplier(3) + 0.5)          # rush hour
        self.assertGreater(t.multiplier(8, rain=True), t.multiplier(8))     # rain slows traffic
        self.assertLess(t.multiplier(8, weekend=True), t.multiplier(8))     # weekend is lighter
        self.assertLess(t.metrics["mae_vs_truth"], 0.05)

    def test_stop_order_ga_hits_exhaustive_optimum(self):
        p = HUB.trip.plan_stops("bastos", ["mvan", "mokolo", "essos", "ekounou", "etoudi"], 8)
        self.assertAlmostEqual(p["total_minutes"], p["optimal_minutes"], places=1)
        self.assertLessEqual(p["total_minutes"], p["given_order_minutes"])
        self.assertLessEqual(p["total_minutes"], p["greedy_minutes"] + 1e-6)

    def test_departure_pso_matches_scan(self):
        d = HUB.trip.best_departure("bastos", "mvan", rain=True)
        self.assertLessEqual(d["best_minutes"], d["scan_best_minutes"] + 0.3)
        self.assertLess(d["best_minutes"], d["worst_minutes"])
        peak = max(d["profile"], key=lambda p: p["minutes"])["hour"]
        self.assertTrue(7 <= peak <= 9 or 16 <= peak <= 19)

    def test_unknown_place(self):
        with self.assertRaises(ValueError):
            HUB.trip.route("atlantis", "mvan")


# -------------------------------------------------------------------- career
class TestCareer(unittest.TestCase):
    def test_learning_path_is_optimal_and_valid(self):
        c = HUB.career
        for role in c.roles:
            for have in ([], ["python", "git"], ["linux", "networking"]):
                p = c.learning_path(have, role)
                self.assertLessEqual(p["total_weeks"], p["naive_weeks"] + 1e-6)
                self.assertLessEqual(p["expanded_astar"], p["expanded_dijkstra"])
                known = set(have)
                for st in p["steps"]:
                    self.assertTrue(set(c.skills[st["skill"]]["prereqs"]) <= known, "prerequisite order")
                    known.add(st["skill"])
                self.assertTrue(set(c.roles[role]["required"]) <= known)
                self.assertAlmostEqual(sum(s["weeks"] for s in p["steps"]), p["total_weeks"], delta=0.1)

    def test_study_plan_respects_budget_and_beats_greedy(self):
        c = HUB.career
        for have, weeks in ([["python", "git"], 8], [[], 12], [["python"], 30]):
            s = c.study_plan(have, weeks)
            self.assertLessEqual(s["used_weeks"], weeks)
            self.assertGreaterEqual(s["value_ga"], s["value_greedy"] - 0.02)
            known = set(have)
            for k in s["skills"]:
                self.assertTrue(set(c.skills[k["skill"]]["prereqs"]) <= known)
                known.add(k["skill"])

    def test_match_ann_beats_linear_and_ranks_sensibly(self):
        c = HUB.career
        self.assertLess(c.metrics["ann_mae_vs_truth"], c.metrics["linear_mae_vs_truth"])
        top = c.match(["flutter", "dart", "git", "rest_api", "testing"], 1)["matches"][0]
        self.assertIn(top["title"], ("Junior Flutter Developer", "Mobile App Developer"))
        self.assertGreater(top["probability"], 0.9)
        low = c.match([], 0)["matches"][0]
        self.assertLess(low["probability"], 0.3)

    def test_bad_input(self):
        with self.assertRaises(ValueError):
            HUB.career.match(["cobol"])
        with self.assertRaises(ValueError):
            HUB.career.learning_path([], "astronaut")


# -------------------------------------------------------------------- health
class TestHealth(unittest.TestCase):
    def test_red_flags_always_emergency(self):
        for flag in ("chest_pain", "shortness_of_breath", "confusion", "severe_bleeding", "stiff_neck"):
            r = HUB.health.triage([flag], "adult", 0, "bastos", 8)
            self.assertEqual(r["level"], "emergency")
            self.assertEqual(HUB.trip.nodes[r["facility"]["to"]]["type"], "hospital")
            self.assertIn("not a diagnosis", r["disclaimer"])

    def test_severity_grows_with_symptoms(self):
        h = HUB.health
        mild = h.triage(["headache"], "adult", 1)["score"]
        worse = h.triage(["fever", "vomiting", "diarrhea", "dehydration_signs"], "older", 5)["score"]
        self.assertGreater(worse, mild + 0.5)
        self.assertEqual(h.triage(["headache"], "adult", 1)["level"], "self_care")

    def test_pso_thresholds_reduce_under_triage(self):
        m = HUB.health.metrics
        self.assertLess(m["under_triage_tuned"], m["under_triage_argmax"])
        self.assertLess(m["cost_tuned"], m["cost_argmax"])
        self.assertGreater(m["accuracy_test"], 0.85)

    def test_nearest_facility_is_truly_nearest(self):
        r = HUB.health.triage(["fever", "vomiting", "diarrhea", "dehydration_signs"], "child", 3, "mvan", 9)
        f = r["facility"]
        self.assertAlmostEqual(f["minutes"], f["alternatives"][0]["minutes"], places=1)

    def test_question_selection(self):
        q = HUB.health.questions()
        self.assertTrue(set(q["selected"]) <= {i["id"] for i in q["importance"]})
        self.assertEqual(q["importance"][0]["id"], "dehydration_signs")

    def test_bad_input(self):
        for bad in (dict(symptoms=[]), dict(symptoms=["fever"], age="alien"), dict(symptoms=["plague"])):
            with self.assertRaises(ValueError):
                HUB.health.triage(bad.get("symptoms"), bad.get("age", "adult"))


# --------------------------------------------------------------------- queue
def bfs_len(a, b):
    W = queue_sim.WALL
    q, seen = deque([(a, 0)]), {a}
    while q:
        (r, c), d = q.popleft()
        if (r, c) == b:
            return d
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (r + dr, c + dc)
            if 0 <= n[0] < W.shape[0] and 0 <= n[1] < W.shape[1] and not W[n] and n not in seen:
                seen.add(n)
                q.append((n, d + 1))


class TestQueue(unittest.TestCase):
    def test_walk_is_shortest_and_avoids_walls(self):
        for c in queue_sim.COUNTERS:
            w = HUB.queue.walk((0, 0), c["cell"])
            self.assertEqual(w["steps"], bfs_len((0, 0), tuple(c["cell"])))
            self.assertTrue(all(not queue_sim.WALL[r, cc] for r, cc in w["path"]))
        with self.assertRaises(ValueError):
            HUB.queue.walk((0, 0), (1, 1))

    def test_duration_ann_beats_baseline(self):
        m = HUB.queue.metrics
        self.assertLess(m["mae_minutes"], 0.7 * m["mae_minutes_mean_baseline"])

    def test_ga_schedule_never_worse_than_baselines(self):
        for seed in (1, 2, 3):
            s = HUB.queue.schedule(HUB.queue.demo_tickets(12, seed))
            self.assertLessEqual(s["weighted_wait_ga"], min(s["weighted_wait_fifo"], s["weighted_wait_wspt"]) + 0.01)
            self.assertEqual(len({p["ticket"] for p in s["plan"]}), 12)
            for p in s["plan"]:
                svc = next(c for c in queue_sim.COUNTERS if c["id"] == p["counter"])["services"]
                self.assertIn(p["service"], svc)
        self.assertGreater(HUB.queue.schedule(HUB.queue.demo_tickets(10, 1))["improvement_vs_fifo_pct"], 5)

    def test_counters_never_overlap(self):
        plan = HUB.queue.schedule(HUB.queue.demo_tickets(15, 7))["plan"]
        for c in queue_sim.COUNTERS:
            slots = sorted((p["start"], p["end"]) for p in plan if p["counter"] == c["id"])
            for (s1, e1), (s2, e2) in zip(slots, slots[1:]):
                self.assertLessEqual(e1, s2 + 0.11)

    def test_pso_dispatch_beats_fifo_on_unseen_days(self):
        t = HUB.queue.tune_dispatch()
        self.assertLess(t["objective_tuned"], t["objective_fifo"])

    def test_recommendation_uses_only_compatible_counters(self):
        r = HUB.queue.recommend("advising", (0, 0), {"C3": 0, "C4": 30})
        self.assertEqual({o["counter"] for o in r["options"]}, {"C3", "C4"})
        self.assertEqual(r["best"]["counter"], "C3")


# ------------------------------------------------------------------ assistant
class TestAssistant(unittest.TestCase):
    def test_intent_validation_set(self):
        ok = sum(HUB.assistant.reply(t)["intent"] == k for t, k in VALIDATION)
        self.assertGreaterEqual(ok / len(VALIDATION), 0.9)

    def test_conversation_keeps_context(self):
        a, ctx = HUB.assistant, {}
        r = a.reply("I know Python and Git", ctx)
        ctx = r["context"]
        self.assertEqual(set(ctx["skills"]), {"python", "git"})
        r = a.reply("how do I become a backend developer?", ctx)
        self.assertEqual(r["intent"], "career_path")
        self.assertNotIn("Python (", r["reply"])          # already known, so not in the plan
        r = a.reply("I am in Bastos", r["context"])
        r = a.reply("I have fever and cough", r["context"])
        self.assertEqual(r["intent"], "health_triage")
        r2 = a.reply("nearest hospital", r["context"])
        self.assertEqual(r2["intent"], "health_clinic")
        self.assertIn("Hospital", r2["reply"])

    def test_route_direction_and_time_parsing(self):
        a = HUB.assistant
        r = a.reply("route to Mvan from Bastos at 8am")
        self.assertEqual(r["data"]["route"]["from"], "bastos")
        self.assertEqual(r["data"]["route"]["to"], "mvan")
        self.assertEqual(r["data"]["route"]["time"], "08:00")
        r = a.reply("when should I leave Bastos for Mvan when it is raining?")
        self.assertTrue(r["data"]["departure"]["rain"])

    def test_missing_info_and_nonsense(self):
        a = HUB.assistant
        self.assertIn("Which two places", a.reply("fastest route please")["reply"])
        self.assertEqual(a.reply("what is the meaning of life")["intent"], "fallback")
        self.assertEqual(a.reply("asdf qwer zxcv")["intent"], "fallback")
        with self.assertRaises(ValueError):
            a.reply("   ")

    def test_french(self):
        r = HUB.assistant.reply("itineraire de Bastos a Mvan")
        self.assertEqual(r["intent"], "trip_route")


# ------------------------------------------------------------------------ API
class TestApi(unittest.TestCase):
    def post(self, path, body=None):
        r = CLIENT.post(path, json=body or {})
        return r.status_code, r.get_json()

    def test_pages_and_meta(self):
        for url in ("/", "/static/app.js", "/static/style.css", "/api/meta", "/api/models"):
            resp = CLIENT.get(url)
            self.assertEqual(resp.status_code, 200, url)
            resp.close()
        meta = CLIENT.get("/api/meta").get_json()
        self.assertEqual(len(meta["career"]["skills"]), 25)
        self.assertEqual(len(CLIENT.get("/api/models").get_json()), 5)

    def test_happy_paths(self):
        cases = [
            ("/api/chat", {"message": "hello"}),
            ("/api/trip/route", {"from": "bastos", "to": "mvan", "hour": 8}),
            ("/api/trip/plan", {"start": "bastos", "stops": ["mvan", "mokolo"], "hour": 8}),
            ("/api/trip/departure", {"from": "bastos", "to": "mvan"}),
            ("/api/career/path", {"have": ["python"], "role": "backend_developer"}),
            ("/api/career/plan", {"have": [], "weeks": 6}),
            ("/api/career/match", {"have": ["python", "sql"], "years": 1}),
            ("/api/health/triage", {"symptoms": ["fever"], "location": "bastos"}),
            ("/api/health/questions", {}),
            ("/api/queue/recommend", {"service": "payments", "cell": [0, 0]}),
            ("/api/queue/schedule", {}),
            ("/api/queue/tune", {}),
        ]
        for path, body in cases:
            code, js = self.post(path, body)
            self.assertEqual(code, 200, (path, js))

    def test_errors_are_400_json(self):
        cases = [
            ("/api/trip/route", {"from": "nowhere", "to": "mvan"}),
            ("/api/trip/plan", {"start": "bastos", "stops": []}),
            ("/api/trip/route", {"from": "bastos", "to": "mvan", "hour": "abc"}),
            ("/api/career/path", {"have": ["cobol"], "role": "backend_developer"}),
            ("/api/career/plan", {"have": [], "weeks": 0}),
            ("/api/health/triage", {"symptoms": []}),
            ("/api/queue/recommend", {"service": "nope"}),
            ("/api/queue/recommend", {"service": "payments", "cell": [1, 1]}),
            ("/api/queue/recommend", {"service": "payments", "cell": "x"}),
            ("/api/chat", {"message": ""}),
        ]
        for path, body in cases:
            code, js = self.post(path, body)
            self.assertEqual(code, 400, (path, body, js))
            self.assertIn("error", js)

    def test_malformed_body_does_not_crash(self):
        r = CLIENT.post("/api/trip/route", data="not json", content_type="application/json")
        self.assertEqual(r.status_code, 400)


if __name__ == "__main__":
    unittest.main(verbosity=2)
