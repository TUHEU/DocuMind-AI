# Put the 16 stories on your GitHub board

Your board: https://github.com/users/TUHEU/projects/3

## One-time setup
1. Install the GitHub CLI: https://cli.github.com (or in PowerShell: `winget install GitHub.cli`). Close and reopen PowerShell.
2. Log in: `gh auth login` (choose GitHub.com, HTTPS, browser).
3. Allow it to edit projects: `gh auth refresh -s project`

## Import
1. Unzip this folder, open PowerShell inside it.
2. If PowerShell blocks scripts: `Set-ExecutionPolicy -Scope Process Bypass`
3. Run: `.\import-board.ps1`
4. Refresh the board page. Each story appears as a card in its column. Open one to see the story and its tick boxes.

Run it only once, otherwise you get duplicates (delete extras with the card's "..." menu, then "Delete from project").

## Fix the column descriptions (optional)
Your Backlog column says "This is actively being worked on" and To Do says "This has been completed". These are mixed up.
For each column click "..." > Edit details and use:
- Backlog: Stories not yet started.
- To Do: Stories selected for upcoming work.
- In Progress: Stories currently being implemented.
- Review: Waiting for supervisor or self-check.
- Done: Stories meeting all acceptance criteria.

## Without the script (manual)
Click "+ Add item" at the bottom, paste the title and body from stories.json, then drag the card to its column.
