# Fills your GitHub Project with the 16 DocuMind AI user stories and sets each Status column.
# Run from this folder in PowerShell:  .\import-board.ps1
param(
  [int]$Project = 3,
  [string]$Owner = "TUHEU"
)
$ErrorActionPreference = "Stop"

# Check that the GitHub CLI is installed and allowed to edit projects
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { throw "GitHub CLI (gh) is not installed. See README.md step 1." }
gh auth status | Out-Null

$stories = Get-Content (Join-Path $PSScriptRoot "stories.json") -Raw -Encoding UTF8 | ConvertFrom-Json

$projId = (gh project view $Project --owner $Owner --format json | ConvertFrom-Json).id
$fields = (gh project field-list $Project --owner $Owner --format json | ConvertFrom-Json).fields
$status = $fields | Where-Object { $_.name -eq "Status" }
if (-not $status) { throw "No 'Status' field found on project $Project." }

$options = @{}
foreach ($o in $status.options) { $options[$o.name] = $o.id }

foreach ($s in $stories) {
  if (-not $options.ContainsKey($s.status)) { throw "Column '$($s.status)' does not exist on the board. Existing: $($options.Keys -join ', ')" }
  $item = gh project item-create $Project --owner $Owner --title $s.title --body $s.body --format json | ConvertFrom-Json
  gh project item-edit --id $item.id --project-id $projId --field-id $status.id --single-select-option-id $options[$s.status] | Out-Null
  Write-Host "Added  $($s.title)  ->  $($s.status)"
}
Write-Host "`nDone. Refresh your board page."
