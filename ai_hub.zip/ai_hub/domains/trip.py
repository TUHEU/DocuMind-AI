"""Trip planning on a Yaounde road graph.

* ANN   - predicts a traffic multiplier from hour / rain / weekend.
* A*    - fastest (or shortest) route between two places; also nearest facility.
* GA    - best visiting order for a multi-stop trip (travelling-salesman style).
* PSO   - best departure hour inside a time window.
"""
from __future__ import annotations

import itertools
import json
import math
from pathlib import Path

import numpy as np

from core.nn import MLP, load_or_train
from core.optimize import ga_permutation, pso
from core.search import astar
from core.text import normalize

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
FREE_FLOW_KMH = 35.0
ROAD_FACTOR = 1.3      # roads are longer than the straight line between two places
K_NEAREST = 3


def haversine(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def fmt_hour(h):
    m = int(round((h % 24) * 60))
    return f"{(m // 60) % 24:02d}:{m % 60:02d}"


# ------------------------------------------------------------- traffic (ANN)
def true_multiplier(hour, rain, weekend):
    """Synthetic ground truth used to generate training data (>= 1.0)."""
    hour = np.asarray(hour, dtype=float)
    peak = (0.9 * np.exp(-((hour - 8.0) / 1.3) ** 2)
            + 1.0 * np.exp(-((hour - 17.5) / 1.6) ** 2)
            + 0.35 * np.exp(-((hour - 12.5) / 1.2) ** 2))
    peak = peak * np.where(np.asarray(weekend) > 0, 0.45, 1.0)
    return 1.0 + peak + 0.30 * np.asarray(rain, dtype=float) * (1.0 + 0.5 * peak)


def traffic_features(hour, rain, weekend):
    hour = np.atleast_1d(np.asarray(hour, dtype=float)) % 24.0
    ang = 2 * math.pi * hour / 24.0
    rain = np.broadcast_to(np.asarray(rain, dtype=float), hour.shape)
    weekend = np.broadcast_to(np.asarray(weekend, dtype=float), hour.shape)
    return np.column_stack([np.sin(ang), np.cos(ang), rain, weekend])


class TrafficModel:
    VERSION = "traffic-v1"

    def __init__(self, mlp, metrics):
        self.mlp = mlp
        self.metrics = metrics
        self._cache = {}

    @classmethod
    def build(cls, model_dir, retrain=False):
        def train():
            rng = np.random.default_rng(7)
            n = 5000
            hours = rng.uniform(0, 24, n)
            rain = (rng.random(n) < 0.25).astype(float)
            weekend = (rng.random(n) < 2 / 7).astype(float)
            y = true_multiplier(hours, rain, weekend) + rng.normal(0, 0.05, n)
            mlp = MLP([4, 16, 16, 1], "regression", "tanh", seed=1)
            mlp.fit(traffic_features(hours, rain, weekend), y, epochs=120, lr=0.01, batch=64)
            th = rng.uniform(0, 24, 2000)
            tr = (rng.random(2000) < 0.25).astype(float)
            tw = (rng.random(2000) < 2 / 7).astype(float)
            pred = mlp.predict(traffic_features(th, tr, tw))
            mae = float(np.mean(np.abs(pred - true_multiplier(th, tr, tw))))
            return mlp, {
                "task": "regression", "architecture": "4-16-16-1 tanh", "samples": n,
                "mae_vs_truth": round(mae, 4),
                "note": "Trained on synthetic traffic patterns; replace with real GPS/taxi logs.",
            }
        mlp, metrics = load_or_train(Path(model_dir) / "traffic.json", cls.VERSION, train, retrain)
        return cls(mlp, metrics)

    def multiplier(self, hour, rain=False, weekend=False):
        key = (int(round((hour % 24) * 20)), bool(rain), bool(weekend))
        if key not in self._cache:
            val = float(self.mlp.predict(traffic_features(hour, float(rain), float(weekend)))[0])
            self._cache[key] = max(1.0, val)
        return self._cache[key]


# --------------------------------------------------------------- road graph
class TripPlanner:
    def __init__(self, traffic: TrafficModel):
        self.traffic = traffic
        data = json.loads((DATA_DIR / "yaounde.json").read_text(encoding="utf-8"))
        self.nodes = {n["id"]: n for n in data["nodes"]}
        self.order = [n["id"] for n in data["nodes"]]
        self.adj = {i: {} for i in self.order}
        self._build_graph()

    # -- graph
    def dist(self, a, b):
        na, nb = self.nodes[a], self.nodes[b]
        return haversine(na["lat"], na["lon"], nb["lat"], nb["lon"])

    def _add_edge(self, a, b):
        km = self.dist(a, b) * ROAD_FACTOR
        self.adj[a][b] = km
        self.adj[b][a] = km

    def _build_graph(self):
        """Landmarks form the road network; facilities hang off their 2 nearest landmarks."""
        lands = [i for i in self.order if self.nodes[i]["type"] == "landmark"]
        facilities = [i for i in self.order if self.nodes[i]["type"] != "landmark"]
        for a in lands:
            nearest = sorted((self.dist(a, b), b) for b in lands if b != a)[:K_NEAREST]
            for _, b in nearest:
                self._add_edge(a, b)
        parent = {i: i for i in lands}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        for a in lands:
            for b in self.adj[a]:
                parent[find(a)] = find(b)
        while len({find(i) for i in lands}) > 1:
            best = None
            for a in lands:
                for b in lands:
                    if find(a) != find(b):
                        d = self.dist(a, b)
                        if best is None or d < best[0]:
                            best = (d, a, b)
            _, a, b = best
            self._add_edge(a, b)
            parent[find(a)] = find(b)
        for f in facilities:
            for _, b in sorted((self.dist(f, b), b) for b in lands)[:2]:
                self._add_edge(f, b)

    def _allowed(self, *endpoints):
        """Facilities are never used as transit points, only as start or destination."""
        ends = set(endpoints)
        return lambda n: self.nodes[n]["type"] == "landmark" or n in ends

    def edges(self):
        seen, out = set(), []
        for a, nbrs in self.adj.items():
            for b in nbrs:
                if (b, a) not in seen:
                    seen.add((a, b))
                    out.append((a, b))
        return out

    def resolve(self, ref):
        if ref in self.nodes:
            return ref
        q = normalize(ref)
        for i, n in self.nodes.items():
            if normalize(n["name"]) == q or q in [normalize(a) for a in n.get("aliases", [])]:
                return i
        matches = [i for i, n in self.nodes.items() if q and q in normalize(n["name"])]
        if len(matches) == 1:
            return matches[0]
        raise ValueError(f"Unknown place: {ref!r}")

    def name(self, i):
        return self.nodes[i]["name"]

    def public_nodes(self):
        return [{"id": n["id"], "name": n["name"], "lat": n["lat"], "lon": n["lon"],
                 "type": n["type"]} for n in self.nodes.values()]

    # -- routing
    def _cost_fn(self, mode, mult):
        if mode == "distance":
            return lambda km: km
        return lambda km: km / FREE_FLOW_KMH * mult

    def _package(self, path, hour, rain, weekend, mult, mode, expanded, expanded_ref):
        km = sum(self.adj[x][y] for x, y in zip(path, path[1:]))
        return {
            "from": path[0], "to": path[-1], "path": path,
            "names": [self.name(p) for p in path],
            "km": round(km, 2),
            "minutes": round(km / FREE_FLOW_KMH * mult * 60, 1),
            "free_flow_minutes": round(km / FREE_FLOW_KMH * 60, 1),
            "multiplier": round(mult, 3), "hour": hour, "time": fmt_hour(hour),
            "rain": bool(rain), "weekend": bool(weekend), "mode": mode,
            "expanded_astar": expanded, "expanded_dijkstra": expanded_ref,
        }

    def route(self, origin, dest, hour=12.0, rain=False, weekend=False, mode="time", compare=True):
        a, b = self.resolve(origin), self.resolve(dest)
        mult = self.traffic.multiplier(hour, rain, weekend)
        unit = self._cost_fn(mode, mult)
        ok = self._allowed(a, b)

        def neighbors(s):
            return [(n, unit(km), None) for n, km in self.adj[s].items() if ok(n)]

        res = astar(a, lambda s: s == b, neighbors, lambda s: unit(self.dist(s, b)))
        ref = astar(a, lambda s: s == b, neighbors)["expanded"] if compare else None
        return self._package(res["path"], hour, rain, weekend, mult, mode, res["expanded"], ref)

    def nearest(self, origin, goals, hour=12.0, rain=False, weekend=False):
        """A* from origin to the closest of several goal nodes (multi-goal heuristic)."""
        a = self.resolve(origin)
        goalset = {self.resolve(g) for g in goals}
        mult = self.traffic.multiplier(hour, rain, weekend)
        unit = self._cost_fn("time", mult)
        ok = self._allowed(a, *goalset)

        def neighbors(s):
            return [(n, unit(km), None) for n, km in self.adj[s].items() if ok(n)]

        def h(s):
            return min(unit(self.dist(s, g)) for g in goalset)

        res = astar(a, lambda s: s in goalset, neighbors, h)
        if res is None:
            return None
        return self._package(res["path"], hour, rain, weekend, mult, "time", res["expanded"], None)

    # -- GA: multi-stop ordering
    def plan_stops(self, start, stops, hour=12.0, rain=False, weekend=False,
                   round_trip=False, seed=0):
        s0 = self.resolve(start)
        stop_ids = []
        for s in stops:
            sid = self.resolve(s)
            if sid != s0 and sid not in stop_ids:
                stop_ids.append(sid)
        if not stop_ids:
            raise ValueError("Add at least one stop different from the start.")
        ids = [s0] + stop_ids
        k = len(stop_ids)
        legs = {}
        for i, a in enumerate(ids):
            for j, b in enumerate(ids):
                if i != j:
                    legs[(i, j)] = self.route(a, b, hour, rain, weekend, compare=False)
        M = {key: leg["minutes"] for key, leg in legs.items()}

        def total(perm):
            seq = [0] + [p + 1 for p in perm]
            t = sum(M[(x, y)] for x, y in zip(seq, seq[1:]))
            if round_trip:
                t += M[(seq[-1], 0)]
            return t

        # greedy nearest-neighbour order as a seed
        left, cur, greedy = set(range(1, k + 1)), 0, []
        while left:
            nxt = min(left, key=lambda j: M[(cur, j)])
            greedy.append(nxt - 1)
            left.remove(nxt)
            cur = nxt
        given = list(range(k))
        ga = ga_permutation(k, total, pop_size=50, generations=80, seed=seed,
                            seeds=[given, greedy])
        best = ga["best"]
        optimal = None
        if k <= 7:
            optimal = min(total(list(p)) for p in itertools.permutations(range(k)))
        seq = [0] + [p + 1 for p in best] + ([0] if round_trip else [])
        out_legs = []
        for x, y in zip(seq, seq[1:]):
            leg = legs[(x, y)]
            out_legs.append({"from": ids[x], "to": ids[y], "from_name": self.name(ids[x]),
                             "to_name": self.name(ids[y]), "minutes": leg["minutes"],
                             "km": leg["km"], "path": leg["path"]})
        base, best_cost = total(given), total(best)
        step = max(1, len(ga["history"]) // 40)
        return {
            "order": [ids[i] for i in seq], "order_names": [self.name(ids[i]) for i in seq],
            "legs": out_legs, "total_minutes": round(best_cost, 1),
            "given_order_minutes": round(base, 1),
            "saved_minutes": round(base - best_cost, 1),
            "greedy_minutes": round(total(greedy), 1),
            "optimal_minutes": None if optimal is None else round(optimal, 1),
            "history": [round(v, 2) for v in ga["history"][::step]],
            "evaluations": ga["evaluations"], "hour": hour, "time": fmt_hour(hour),
            "round_trip": round_trip,
        }

    # -- PSO: departure time
    def best_departure(self, origin, dest, rain=False, weekend=False,
                       earliest=5.0, latest=22.0, seed=0):
        if latest <= earliest:
            raise ValueError("The latest departure must be after the earliest one.")
        base = self.route(origin, dest, 12.0, rain, weekend, compare=False)
        free = base["free_flow_minutes"]

        def minutes(h):
            return free * self.traffic.multiplier(float(h), rain, weekend)

        res = pso(lambda x: minutes(x[0]), [(earliest, latest)], particles=16, iters=30, seed=seed)
        grid = np.arange(earliest, latest + 1e-9, 0.25)
        scan = min(grid, key=minutes)
        profile = [{"hour": float(h), "minutes": round(minutes(h), 1)}
                   for h in np.arange(math.ceil(earliest), math.floor(latest) + 1e-9, 1.0)]
        return {
            "from": base["from"], "to": base["to"], "names": base["names"], "path": base["path"],
            "km": base["km"], "free_flow_minutes": free,
            "best_hour": round(res["x"][0], 3), "best_time": fmt_hour(res["x"][0]),
            "best_minutes": round(res["f"], 1),
            "scan_best_time": fmt_hour(scan), "scan_best_minutes": round(minutes(scan), 1),
            "worst_minutes": round(max(p["minutes"] for p in profile), 1),
            "profile": profile, "history": [round(v, 2) for v in res["history"]],
            "evaluations": res["evaluations"], "rain": bool(rain), "weekend": bool(weekend),
        }
