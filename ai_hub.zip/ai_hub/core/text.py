"""Text helpers shared by the assistant and the domain modules."""
from __future__ import annotations

import re
import unicodedata


def normalize(text: str) -> str:
    """Lower-case, strip accents and apostrophes, and reduce punctuation to spaces."""
    t = unicodedata.normalize("NFKD", str(text))
    t = "".join(c for c in t if not unicodedata.combining(c)).lower()
    t = t.replace("'", "").replace("\u2019", "")
    t = re.sub(r"[^a-z0-9]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()
