"""Chat assistant.

An ANN (bag-of-words MLP) classifies the intent of each message, a lexicon-based
extractor pulls out places, skills, roles, symptoms and numbers, and the matching
domain module (search / optimisation / neural nets) produces the answer.
Works fully offline.
"""
from __future__ import annotations

import datetime
import random
import re
from pathlib import Path

import numpy as np

from core.nn import MLP, load_or_train
from core.text import normalize

SYMPTOM_ALIASES = {
    "fever": ["fever", "feverish", "high temperature", "temperature", "fievre"],
    "cough": ["cough", "coughing", "toux"],
    "sore_throat": ["sore throat", "throat pain", "mal de gorge"],
    "headache": ["headache", "head hurts", "migraine", "mal de tete"],
    "fatigue": ["tired", "tiredness", "fatigue", "exhausted", "weak", "fatigue"],
    "muscle_ache": ["muscle ache", "muscle aches", "body ache", "body aches", "body pain", "courbatures"],
    "diarrhea": ["diarrhea", "diarrhoea", "loose stool", "diarrhee"],
    "vomiting": ["vomiting", "vomit", "throwing up", "vomissements"],
    "abdominal_pain": ["stomach pain", "abdominal pain", "stomach ache", "belly pain", "tummy ache",
                       "mal au ventre"],
    "rash": ["rash", "skin rash", "spots on skin"],
    "loss_of_smell": ["loss of smell", "cant smell", "lost my smell", "loss of taste"],
    "dehydration_signs": ["dehydrated", "dehydration", "very dry mouth"],
    "chest_pain": ["chest pain", "chest pressure", "chest tightness", "douleur thoracique"],
    "shortness_of_breath": ["shortness of breath", "cant breathe", "difficulty breathing",
                            "trouble breathing", "hard to breathe"],
    "confusion": ["confused", "confusion", "fainted", "fainting", "passed out", "unconscious"],
    "severe_bleeding": ["heavy bleeding", "bleeding heavily", "wont stop bleeding", "severe bleeding"],
    "stiff_neck": ["stiff neck"],
}
SERVICE_ALIASES = {
    "registration": ["registration", "register", "enrolment", "enrollment", "inscription"],
    "payments": ["fees", "payment", "payments", "pay", "tuition", "frais", "paiement"],
    "transcripts": ["transcript", "transcripts", "certificate", "releve de notes"],
    "advising": ["advising", "advisor", "adviser", "academic advice", "conseil academique"],
}
CHILD_WORDS = ["child", "kid", "baby", "toddler", "son", "daughter", "enfant", "bebe"]
OLDER_WORDS = ["elderly", "grandmother", "grandfather", "grandma", "grandpa", "senior", "old man",
               "old woman", "older"]

TEMPLATES = {
    "greet": ["hi", "hello", "hey", "good morning", "bonjour", "salut", "hello there", "hey there",
              "good evening", "bonsoir", "hi there", "hello assistant"],
    "help": ["help", "what can you do", "how does this work", "what can i ask you",
             "show me what you can do", "aide", "que peux tu faire", "list your features",
             "what are your commands", "how do i use this", "i need help", "what do you know"],
    "thanks": ["thanks", "thank you", "merci", "thanks a lot", "great thanks", "ok thank you",
               "cool thanks", "i appreciate it", "perfect thank you", "merci beaucoup", "thx", "cheers", "many thanks", "that was helpful"],
    "location": ["i am in Bastos", "i am at Mokolo", "my location is Essos", "je suis a Melen",
                 "i live near Mvan", "im currently in Obili", "i am at the Airport",
                 "i m in Etoudi right now", "we are at Biyem-Assi", "je me trouve a Mendong",
                 "i am standing at Omnisports", "currently in Ekounou"],
    "profile": ["i know python and sql", "my skills are python git and flutter",
                "i have experience with docker", "i can code in python", "i am comfortable with linux and networking",
                "je connais python et sql", "i learned flutter and dart", "i already know git",
                "my skills: python, sql", "i studied networking and linux", "i also know react",
                "i have used flask and mysql", "i am good at javascript and html", "add pandas to my skills",
                "i know machine learning and statistics"],
    "trip_route": ["how do i get from Bastos to Mvan", "fastest route from Mokolo to Essos",
                   "route from Etoudi to Biyem-Assi", "directions Bastos to Ekounou",
                   "how long from Melen to Mvan", "shortest way to Mvan from Bastos",
                   "i want to go from Obili to Nlongkak", "itineraire de Bastos a Mvan",
                   "how far is Mvan from Bastos", "travel time Mokolo to Ekounou",
                   "take me from Centre Ville to the Airport at 8 am",
                   "route Bastos Mvan when it is raining", "how do i get to Mvan from Bastos",
                   "what is the quickest way from Essos to Mendong", "best road from Omnisports to Obili", "fastest route from Essos to Mvan on saturday",
                   "quickest way Mokolo to Bastos when it rains", "route from Melen to Bastos on a rainy morning",
                   "how can i go to the Airport from Bastos", "drive from Melen to Etoudi"],
    "trip_plan": ["plan a trip visiting Bastos Mvan and Essos", "best order to visit Mokolo Mvan Etoudi",
                  "i need to stop at Essos Mvan and Ekounou starting from Bastos",
                  "optimize my errands Mokolo Essos Mvan", "plan my day visiting Bastos, Melen, Mvan",
                  "what order should i visit Mokolo Essos Etoudi", "tour of Bastos Mvan Essos Ekounou",
                  "multi stop route Bastos Mokolo Mvan", "organise mes courses Bastos Mvan Essos",
                  "errands in Mokolo Essos and Mvan", "i have several stops Mvan Essos Etoudi from Bastos",
                  "arrange the stops Melen Obili Mvan for me", "visit Mvan Essos and Mokolo in the best order",
                  "several places to visit Bastos Mvan Essos what order",
                  "what sequence should i follow for Bastos Mvan Essos", "put my stops Mokolo Essos Mvan in a good sequence"],
    "trip_departure": ["when should i leave to go from Bastos to Mvan", "best time to travel from Mokolo to Essos",
                       "what time should i leave to avoid traffic Bastos to Mvan",
                       "when is traffic lightest from Etoudi to Mvan", "best departure time Bastos to Ekounou",
                       "should i leave early or late to reach Mvan", "when to leave for the Airport",
                       "quand partir de Bastos a Mvan", "avoid rush hour going to Mvan",
                       "least traffic hour Mokolo Essos", "what is the best hour to drive from Melen to Mvan",
                       "when should i go to Mvan to skip the jams", "ideal time to leave Bastos for Essos",
                       "which hour has the least traffic to the Airport",
                       "when should i leave Mokolo for Essos if it is raining",
                       "best time to travel from Mvan to Bastos on a rainy weekend",
                       "what time should i depart Etoudi to Mvan when it rains",
                       "when to leave Bastos for the Airport on saturday",
                       "when is the best moment to go to Mvan on a rainy day"],
    "career_path": ["how do i become a backend developer", "learning path for ml engineer",
                    "what should i learn to become a mobile developer", "roadmap to security analyst",
                    "i want to be a devops engineer what do i need to learn", "how to become a full stack developer",
                    "skills needed for backend developer", "plan my learning for mobile developer",
                    "what do i need to study to be a security analyst", "comment devenir devops engineer",
                    "fastest way to become a data scientist", "i know python and want to become a backend developer",
                    "career path to machine learning engineer", "steps to become a web developer",
                    "what skills does a mobile developer need", "how can i become an ml engineer",
                    "show me a roadmap to become a backend developer", "guide me towards becoming a devops engineer",
                    "what is the learning roadmap for a mobile developer", "i dream of becoming a data scientist what now"],
    "career_match": ["which jobs fit my skills", "what jobs match me", "find me jobs", "am i qualified for any job",
                     "match me with job openings", "what job can i apply for with my skills", "jobs for me",
                     "quels emplois me conviennent", "which jobs can i get with python and sql",
                     "what positions suit my profile", "recommend jobs for me", "show me matching vacancies",
                     "can i get a job with my current skills", "what are my chances for the open jobs",
                     "rank the jobs for me"],
    "career_plan": ["what should i learn in 8 weeks", "best skills to learn in 6 weeks",
                    "i have 10 weeks to study what should i pick", "study plan 12 weeks to get more jobs",
                    "which skills unlock the most jobs in 8 weeks", "plan my next 6 weeks of learning",
                    "what to learn with 4 weeks", "quelles competences apprendre en 8 semaines",
                    "i have 3 months maximize my job options", "short study plan for more job offers",
                    "which skills should i study in 2 months", "with 5 weeks of free time what should i learn",
                    "what is the smartest thing to study in 8 weeks",
                    "how should i spend 6 weeks studying", "how to use 4 weeks to improve my job chances"],
    "health_triage": ["i have fever and cough", "i feel sick with headache and tiredness",
                      "my child has vomiting and diarrhea", "should i see a doctor i have a rash",
                      "i have had fever for 3 days", "how serious is a headache and sore throat",
                      "symptom check cough and fatigue", "j ai de la fievre et de la toux",
                      "i am having chest pain is it urgent", "my mother has stomach pain and vomiting",
                      "i think i am sick", "i do not feel well", "i have been coughing for 5 days",
                      "is it serious if i have diarrhea and fever", "my son has a high temperature and a rash",
                      "should i worry about muscle aches and fever", "i am dehydrated and vomiting"],
    "health_clinic": ["nearest hospital", "where is the closest clinic", "nearest hospital to Bastos",
                      "closest health centre from Mokolo", "where can i get medical care near Essos",
                      "find a clinic near Mvan", "hopital le plus proche", "i need a hospital near Melen",
                      "nearest emergency room", "closest clinic", "where is the nearest health centre",
                      "which hospital is closest to Obili", "find me a doctor near Ekounou",
                      "closest place to get treated near Biyem-Assi",
                      "is there a hospital close to Mokolo", "a health centre close to Melen please",
                      "find the closest hospital around Obili", "where is a clinic close to Ekounou",
                      "any clinic around Essos", "i need a doctor close to Mvan"],
    "queue_recommend": ["which counter should i go to for registration", "where should i queue for fees",
                        "shortest queue for transcripts", "how long is the wait for advising",
                        "best counter for payments now", "i need to do registration which counter",
                        "quel guichet pour l inscription", "where do i go for transcripts fastest",
                        "wait time for advising", "which line is quickest for fees",
                        "which desk should i use for registration", "where is the shortest line for payments",
                        "how long will i wait to pay my fees"],
    "queue_schedule": ["optimize the queue", "assign tickets to counters", "schedule the waiting tickets",
                       "reorder the queue to reduce waiting", "how to serve waiting students faster",
                       "optimise counter assignment", "improve queue order", "best order to serve the queue",
                       "organise la file d attente", "reduce waiting time at the counters",
                       "how should we serve the students in line", "speed up the service desk",
                       "plan the counter schedule for the waiting tickets",
                       "how can we reduce the waiting time", "make the line move faster at the desk",
                       "students are waiting too long what can we do", "cut the waiting queue at the counters",
                       "how do we shorten the queue"],
}

# Phrasings that never appear in TEMPLATES - used to report validation accuracy.
VALIDATION = [
    ("hello!", "greet"), ("hey good afternoon", "greet"), ("what can you help me with", "help"),
    ("thanks so much", "thanks"), ("i am in Nlongkak", "location"),
    ("i also know docker and linux", "profile"), ("i have learnt html and javascript", "profile"),
    ("what is the fastest way from Mokolo to Bastos", "trip_route"),
    ("how do i reach Ekounou from Melen", "trip_route"),
    ("give me directions from Essos to the Airport", "trip_route"),
    ("plan my errands Bastos Essos Mvan Mokolo", "trip_plan"),
    ("what is the best order for visiting Etoudi Mvan and Melen", "trip_plan"),
    ("when is the best time to leave Mokolo for Mvan", "trip_departure"),
    ("what hour should i depart from Bastos to Essos to avoid jams", "trip_departure"),
    ("what should i learn to become a devops engineer", "career_path"),
    ("give me a roadmap for becoming a security analyst", "career_path"),
    ("which jobs am i a good fit for", "career_match"),
    ("what jobs can i apply to", "career_match"),
    ("what should i study in 6 weeks", "career_plan"),
    ("i have 4 weeks which skills should i learn", "career_plan"),
    ("i have a headache and a cough", "health_triage"),
    ("my daughter has fever and vomiting", "health_triage"),
    ("where is the nearest hospital to Essos", "health_clinic"),
    ("find a clinic close to Bastos", "health_clinic"),
    ("which counter has the shortest line for fees", "queue_recommend"),
    ("where should i go for advising", "queue_recommend"),
    ("how can we shorten the waiting line", "queue_schedule"),
    ("optimise the tickets waiting at the desk", "queue_schedule"),
]

STOP_TOKENS = {"the", "a", "an"}


class Lexicon:
    def __init__(self, trip, career):
        entries = {}

        def add(alias, kind, ident):
            a = normalize(alias)
            if a and a not in entries:
                entries[a] = (kind, ident)

        for nid, n in trip.nodes.items():
            add(n["name"], "place", nid)
            add(re.sub(r"\(.*?\)", "", n["name"]), "place", nid)
            for a in n.get("aliases", []):
                add(a, "place", nid)
        for rid, r in career.roles.items():
            add(r["name"], "role", rid)
            for a in r["aliases"]:
                add(a, "role", rid)
        for sid, s in career.skills.items():
            add(s["name"], "skill", sid)
            for a in s["aliases"]:
                add(a, "skill", sid)
        for sid, al in SYMPTOM_ALIASES.items():
            for a in al:
                add(a, "symptom", sid)
        for sid, al in SERVICE_ALIASES.items():
            for a in al:
                add(a, "service", sid)
        self.entries = sorted(((a, k, i) for a, (k, i) in entries.items()), key=lambda e: -len(e[0]))
        self.patterns = [(re.compile(r"(?<![a-z0-9])" + re.escape(a) + r"(?![a-z0-9])"), k, i)
                         for a, k, i in self.entries]


def parse_hour(norm):
    m = re.search(r"\b(\d{1,2})(?: (\d{2}))? ?(am|pm)\b", norm)
    if m:
        h = int(m.group(1)) % 12 + (12 if m.group(3) == "pm" else 0)
        return h + (int(m.group(2)) / 60 if m.group(2) else 0)
    m = re.search(r"\b(\d{1,2}) ?h\b", norm)
    if m and int(m.group(1)) < 24:
        return float(m.group(1))
    for word, h in (("rush hour", 17.5), ("morning", 8.0), ("noon", 12.0), ("midday", 12.0),
                    ("afternoon", 15.0), ("evening", 18.0), ("tonight", 21.0), ("night", 21.0)):
        if re.search(r"\b" + word + r"\b", norm):
            return h
    return None


class Assistant:
    VERSION = "intent-v5"
    MIN_CONFIDENCE = 0.9

    def __init__(self, hub, mlp, metrics):
        self.hub = hub
        self.mlp = mlp
        self.metrics = metrics
        self.intents = metrics["intents"]
        self.vocab = {t: i for i, t in enumerate(metrics["vocab"])}
        self.lex = Lexicon(hub.trip, hub.career)

    # ------------------------------------------------------------- extraction
    @staticmethod
    def _tokens(masked):
        toks = [t for t in masked.split() if t not in STOP_TOKENS]
        return toks + [a + "_" + b for a, b in zip(toks, toks[1:])]

    def _vectorize(self, masked):
        v = np.zeros(len(self.vocab))
        for t in self._tokens(masked):
            if t in self.vocab:
                v[self.vocab[t]] = 1.0
        return v

    @staticmethod
    def extract_with(lex, text):
        norm = normalize(text)
        taken = [False] * len(norm)
        spans = []
        for pat, kind, ident in lex.patterns:
            for m in pat.finditer(norm):
                s, e = m.span()
                if any(taken[s:e]):
                    continue
                for i in range(s, e):
                    taken[i] = True
                spans.append((s, e, kind, ident))
        spans.sort()
        masked = norm
        for s, e, kind, _ in reversed(spans):
            masked = masked[:s] + "x" + kind + masked[e:]
        masked = re.sub(r"\d+", "xnum", masked)

        def uniq(kind):
            out = []
            for _, _, k, i in spans:
                if k == kind and i not in out:
                    out.append(i)
            return out

        def num(pattern):
            m = re.search(pattern, norm)
            return int(m.group(1)) if m else None

        days = num(r"(\d+) ?(?:days?|jours?)")
        if days is None:
            days = 1 if re.search(r"\byesterday\b|\bhier\b", norm) else (3 if "few days" in norm else None)
        age = "child" if any(re.search(r"\b" + w + r"\b", norm) for w in CHILD_WORDS) else \
              "older" if any(re.search(r"\b" + w + r"\b", norm) for w in OLDER_WORDS) else None
        return {
            "norm": norm, "masked": masked,
            "places": uniq("place"), "roles": uniq("role"), "skills": uniq("skill"),
            "symptoms": uniq("symptom"), "services": uniq("service"),
            "weeks": num(r"(\d+) ?(?:weeks?|wks?|semaines?)"), "months": num(r"(\d+) ?(?:months?|mois)"),
            "days": days, "years": num(r"(\d+) ?(?:years?|yrs?|ans)\b"), "hour": parse_hour(norm),
            "rain": bool(re.search(r"\b(rain|rains|raining|rainy|pluie|pleut)\b", norm)),
            "weekend": bool(re.search(r"\b(weekend|saturday|sunday|samedi|dimanche)\b", norm)),
            "age": age,
        }

    def extract(self, text):
        return self.extract_with(self.lex, text)

    # ---------------------------------------------------------------- training
    @classmethod
    def build(cls, hub, model_dir, retrain=False):
        lex = Lexicon(hub.trip, hub.career)

        def masked(text):
            return cls.extract_with(lex, text)["masked"]

        def train():
            rng = random.Random(41)
            intents = list(TEMPLATES)
            base = [(masked(p), intents.index(k)) for k, ps in TEMPLATES.items() for p in ps]
            vocab_set = set()
            for m, _ in base:
                vocab_set.update(cls._tokens(m))
            vocab = sorted(vocab_set)
            index = {t: i for i, t in enumerate(vocab)}

            def vec(m):
                v = np.zeros(len(vocab))
                for t in cls._tokens(m):
                    if t in index:
                        v[index[t]] = 1.0
                return v

            X, y = [], []
            for m, label in base:
                words = m.split()
                X.append(vec(m))
                y.append(label)
                for _ in range(10):
                    kept = [w for w in words if rng.random() > 0.15] or words
                    if len(kept) < 2 and len(words) >= 2:
                        kept = words
                    X.append(vec(" ".join(kept)))
                    y.append(label)
            X, y = np.array(X), np.array(y)
            mlp = MLP([len(vocab), 48, len(intents)], "classification", "tanh", seed=5)
            mlp.fit(X, y, epochs=60, lr=0.01, batch=32)
            train_acc = float(np.mean(mlp.predict_class(X) == y))
            Xv = np.array([vec(masked(t)) for t, _ in VALIDATION])
            yv = np.array([intents.index(k) for _, k in VALIDATION])
            val_acc = float(np.mean(mlp.predict_class(Xv) == yv))
            return mlp, {
                "task": "classification", "architecture": f"{len(vocab)}-48-{len(intents)} tanh",
                "samples": len(X), "train_accuracy": round(train_acc, 4),
                "validation_accuracy": round(val_acc, 4), "validation_size": len(VALIDATION),
                "intents": intents, "vocab": vocab,
                "note": "Bag-of-words intent model trained on hand-written example phrases (EN/FR).",
            }

        mlp, metrics = load_or_train(Path(model_dir) / "intent.json", cls.VERSION, train, retrain)
        return cls(hub, mlp, metrics)

    def classify(self, text):
        ents = self.extract(text)
        vec = self._vectorize(ents["masked"])
        if vec.sum() == 0:                       # no word the model has ever seen
            return "fallback", 0.0, ents
        probs = self.mlp.predict(vec)[0]
        i = int(probs.argmax())
        return self.intents[i], float(probs[i]), ents

    # ------------------------------------------------------------------- reply
    def reply(self, message, context=None):
        message = (message or "").strip()
        if not message:
            raise ValueError("Write a message first.")
        ctx = dict(context or {})
        intent, conf, ents = self.classify(message)
        if ents["skills"]:
            ctx["skills"] = sorted(set(ctx.get("skills", [])) | set(ents["skills"]))
        if ents["symptoms"]:
            ctx["symptoms"] = sorted(set(ctx.get("symptoms", [])) | set(ents["symptoms"]))
        if ents["age"]:
            ctx["age"] = ents["age"]
        if ents["years"] is not None and intent in ("profile", "career_match", "career_path"):
            ctx["years"] = ents["years"]
        if intent == "location" and ents["places"]:
            ctx["location"] = ents["places"][0]
        hour = ents["hour"] if ents["hour"] is not None else self._now_hour()
        if conf < self.MIN_CONFIDENCE:
            intent = "fallback"
        handler = getattr(self, "_h_" + intent, self._h_fallback)
        text, data = handler(ents, ctx, hour)
        return {"reply": text, "intent": intent, "confidence": round(conf, 3),
                "entities": {k: ents[k] for k in ("places", "roles", "skills", "symptoms", "services",
                                                   "weeks", "days", "hour", "rain", "weekend", "age")},
                "context": ctx, "data": data}

    @staticmethod
    def _now_hour():
        n = datetime.datetime.now()
        return n.hour + n.minute / 60

    def _pn(self, pid):
        return self.hub.trip.name(pid)

    # ---- small talk
    def _h_greet(self, e, c, h):
        return ("Hi! I can plan routes in Yaounde, map out a career path, run a basic symptom check and "
                "organise a service-desk queue. Try: \"fastest way from Bastos to Mvan at 8am\".", None)

    def _h_help(self, e, c, h):
        return ("Ask me things like:\n"
                "- \"Fastest way from Bastos to Mvan at 8am\"\n"
                "- \"Best order to visit Mokolo, Essos and Mvan starting from Bastos\"\n"
                "- \"When should I leave Bastos for Mvan?\"\n"
                "- \"I know Python and Git. How do I become a backend developer?\"\n"
                "- \"Which jobs fit me?\" or \"What should I learn in 8 weeks?\"\n"
                "- \"I have fever and cough\" (educational triage only)\n"
                "- \"Nearest hospital to Mokolo\"\n"
                "- \"Which counter for registration?\" or \"Optimise the queue\"", None)

    def _h_thanks(self, e, c, h):
        return "You're welcome! Ask me anything else.", None

    def _h_fallback(self, e, c, h):
        return ("I didn't quite get that. I can help with routes in Yaounde, careers and skills, "
                "symptom checks, nearest clinics and queue counters. Say \"help\" for examples.", None)

    def _h_location(self, e, c, h):
        if not e["places"]:
            return "Which place are you at? For example: \"I am in Bastos\".", None
        return (f"Got it, you're at {self._pn(e['places'][0])}. I'll use that for routes and clinics.", None)

    def _h_profile(self, e, c, h):
        if not c.get("skills"):
            return "Tell me which skills you know, for example: \"I know Python and SQL\".", None
        names = [self.hub.career.skills[s]["name"] for s in c["skills"]]
        return (f"Noted: {', '.join(names)}. Now ask \"which jobs fit me?\", \"what should I learn in "
                "8 weeks?\" or \"how do I become a backend developer?\".", None)

    # ---- trip
    def _pair(self, e, c):
        places = e["places"]
        if len(places) >= 2:
            a, b = places[0], places[1]
            n = e["norm"]
            if " from " in n and " to " in n and n.find(" to ") < n.find(" from "):
                a, b = b, a
            return a, b
        if len(places) == 1 and c.get("location") and c["location"] != places[0]:
            return c["location"], places[0]
        return None, None

    def _h_trip_route(self, e, c, h):
        if len(e["places"]) >= 3:                 # several places named: this is really a multi-stop trip
            return self._h_trip_plan(e, c, h)
        a, b = self._pair(e, c)
        if not a:
            return "Which two places? For example: \"from Bastos to Mvan\".", None
        r = self.hub.trip.route(a, b, h, e["rain"], e["weekend"])
        via = " → ".join(r["names"][1:-1]) or "a direct road"
        rain = " in the rain" if e["rain"] else ""
        text = (f"Fastest route {r['names'][0]} → {r['names'][-1]} around {r['time']}{rain}: about "
                f"{r['minutes']:.0f} min for {r['km']} km, via {via}. A* checked {r['expanded_astar']} "
                f"places where plain Dijkstra needed {r['expanded_dijkstra']}.")
        return text, {"kind": "route", "route": r}

    def _h_trip_plan(self, e, c, h):
        places = e["places"]
        if len(places) < 3:
            return ("Give me a start and at least two stops, for example: \"visit Mokolo, Essos and Mvan "
                    "starting from Bastos\".", None)
        start, stops = places[0], places[1:]
        if c.get("location") and c["location"] not in places and " from " not in e["norm"]:
            start, stops = c["location"], places
        p = self.hub.trip.plan_stops(start, stops, h, e["rain"], e["weekend"])
        saved = (f"{p['saved_minutes']:.0f} min less than the order you listed"
                 if p["saved_minutes"] > 0.5 else "the same as the order you listed")
        text = (f"Best order: {' → '.join(p['order_names'])}, about {p['total_minutes']:.0f} min in total, "
                f"{saved}. Found by a genetic algorithm over {p['evaluations']} candidate orders.")
        return text, {"kind": "plan", "plan": p}

    def _h_trip_departure(self, e, c, h):
        a, b = self._pair(e, c)
        if not a:
            return "Which trip? For example: \"when should I leave from Bastos to Mvan?\".", None
        d = self.hub.trip.best_departure(a, b, e["rain"], e["weekend"])
        text = (f"For {self._pn(a)} → {self._pn(b)}, leave around {d['best_time']}: about "
                f"{d['best_minutes']:.0f} min, against {d['worst_minutes']:.0f} min at the worst time of day. "
                f"Found by particle swarm optimisation; a 15-minute scan agrees ({d['scan_best_time']}).")
        return text, {"kind": "departure", "departure": d}

    # ---- career
    def _h_career_path(self, e, c, h):
        if not e["roles"]:
            roles = ", ".join(r["name"] for r in self.hub.career.roles.values())
            return f"Which role? I know: {roles}.", None
        p = self.hub.career.learning_path(c.get("skills", []), e["roles"][0])
        if p["already_qualified"]:
            return f"You already have every core skill for {p['role_name']}.", {"kind": "path", "path": p}
        steps = ", ".join(f"{s['name']} ({s['weeks']:.1f}w)" for s in p["steps"])
        start = "your current skills" if c.get("skills") else "scratch (tell me your skills to shorten it)"
        text = (f"Path to {p['role_name']} from {start}: {steps}. Total about {p['total_weeks']:.1f} weeks "
                f"against {p['naive_weeks']:.1f} in a naive order. A* expanded {p['expanded_astar']} states "
                f"(Dijkstra {p['expanded_dijkstra']}).")
        return text, {"kind": "path", "path": p}

    def _h_career_match(self, e, c, h):
        if not c.get("skills"):
            return "Tell me the skills you know first, for example: \"I know Python and SQL\".", None
        m = self.hub.career.match(c["skills"], c.get("years", 0))["matches"][:3]
        lines = "; ".join(f"{r['title']} ({r['city']}) {round(r['probability'] * 100)}% - "
                          f"{r['fit']}" + (f", missing {', '.join(r['missing_names'])}" if r["missing_names"] else "")
                          for r in m)
        return f"Best matches for you: {lines}.", {"kind": "match", "matches": m}

    def _h_career_plan(self, e, c, h):
        weeks = e["weeks"] or ((e["months"] or 0) * 4) or 8
        p = self.hub.career.study_plan(c.get("skills", []), weeks)
        if not p["skills"]:
            return f"Nothing useful fits in {weeks} weeks - try a longer budget.", {"kind": "plan_study", "study": p}
        names = ", ".join(s["name"] for s in p["skills"])
        gained = [t for t in p["qualified_after"] if t not in p["qualified_before"]]
        tail = f" That unlocks: {', '.join(gained)}." if gained else ""
        text = (f"With {weeks} weeks, learn: {names} ({p['used_weeks']:.0f} weeks).{tail} "
                f"The genetic algorithm scored {p['value_ga']} against {p['value_greedy']} for a greedy plan.")
        return text, {"kind": "plan_study", "study": p}

    # ---- health
    def _h_health_triage(self, e, c, h):
        symptoms = c.get("symptoms", [])
        if not symptoms:
            return "What symptoms do you have? For example: \"fever and cough for 2 days\".", None
        age = c.get("age", "adult")
        days = e["days"] if e["days"] is not None else 1
        loc = e["places"][0] if e["places"] else c.get("location")
        r = self.hub.health.triage(symptoms, age, days, loc, h, e["rain"], e["weekend"])
        names = ", ".join(s.replace("_", " ") for s in symptoms)
        text = f"Using: {names} ({age}, {days} day(s)). {r['level_label']}. {r['advice']}"
        if r["facility"]:
            f = r["facility"]
            text += f" Nearest suitable facility: {f['names'][-1]}, about {f['minutes']:.0f} min away."
        elif r["level"] != "self_care":
            text += " Tell me where you are (\"I am in Bastos\") and I'll find the nearest facility."
        return text + " " + r["disclaimer"], {"kind": "triage", "triage": r}

    def _h_health_clinic(self, e, c, h):
        loc = e["places"][0] if e["places"] else c.get("location")
        if not loc:
            return "Where are you? For example: \"nearest hospital to Bastos\".", None
        only_hospital = "hospital" in e["norm"] or "emergency" in e["norm"]
        types = ("hospital",) if only_hospital else ("hospital", "clinic")
        goals = [i for i, n in self.hub.trip.nodes.items() if n["type"] in types]
        r = self.hub.trip.nearest(loc, goals, h, e["rain"], e["weekend"])
        text = (f"Nearest {'hospital' if only_hospital else 'facility'} from {self._pn(loc)}: "
                f"{r['names'][-1]}, about {r['minutes']:.0f} min ({r['km']} km).")
        return text, {"kind": "route", "route": r}

    # ---- queue
    def _h_queue_recommend(self, e, c, h):
        if not e["services"]:
            return "Which service? Registration, payments, transcripts or advising.", None
        r = self.hub.queue.recommend(e["services"][0], (0, 0), None, h)
        b = r["best"]
        text = (f"For {e['services'][0]}, go to counter {b['counter']}: about {b['walk_minutes']:.1f} min "
                f"walk plus {b['wait_minutes']:.0f} min wait ({b['queue_length']} "
                f"{'person' if b['queue_length'] == 1 else 'people'} ahead). "
                f"Assumes you start at the entrance; the current queue is a demo snapshot.")
        return text, {"kind": "queue_recommend", "recommendation": r}

    def _h_queue_schedule(self, e, c, h):
        s = self.hub.queue.schedule(self.hub.queue.demo_tickets(10), h)
        text = (f"For the 10 demo tickets, the genetic algorithm cuts the priority-weighted wait from "
                f"{s['weighted_wait_fifo']} to {s['weighted_wait_ga']} min "
                f"({s['improvement_vs_fifo_pct']}% better than first-come-first-served).")
        return text, {"kind": "queue_schedule", "schedule": s}
