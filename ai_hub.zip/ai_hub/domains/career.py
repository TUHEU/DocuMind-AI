"""Career advisor.

* A*   - cheapest order to learn the skills a role needs (learning gets cheaper
         when you already know related skills, so order matters).
* GA   - which skills to learn inside a weekly budget to unlock the most jobs.
* ANN  - probability of being shortlisted for each job.
* PSO  - fits a transparent linear scorer used to explain what matters.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from core.nn import MLP, load_or_train
from core.optimize import ga_binary, pso
from core.search import astar

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
EDUCATION = ["secondary", "bachelor", "master"]
FEATURE_NAMES = ["required skills covered", "nice-to-have covered", "missing required skills",
                 "experience vs minimum", "education requirement met"]
MIN_DISCOUNT_MULT = 0.5
DISCOUNT_PER_RELATED = 0.12


def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def true_match_prob(f):
    """Synthetic ground truth for the 5 match features (used to generate labels)."""
    full = (f[:, 0] >= 0.999).astype(float)          # every required skill covered
    z = (-4.2 + 2.0 * f[:, 0] + 5.0 * f[:, 0] ** 2 + 1.5 * f[:, 1] - 1.2 * f[:, 2]
         + 0.9 * f[:, 3] * (0.4 + f[:, 0]) + 0.8 * f[:, 4] + 2.0 * full
         - 2.0 * (1.0 - f[:, 0]) * (1.0 - f[:, 4]))
    return _sigmoid(z)


class CareerAdvisor:
    VERSION = "career-v2"

    def __init__(self, mlp, metrics):
        data = json.loads((DATA_DIR / "career.json").read_text(encoding="utf-8"))
        self.skills = data["skills"]
        self.roles = data["roles"]
        self.jobs = data["jobs"]
        self.mlp = mlp
        self.metrics = metrics
        self.linear = metrics.get("linear_scorer", {"w": [0] * 5, "b": 0})

    # ----------------------------------------------------------------- helpers
    def check_skills(self, skills):
        bad = [s for s in skills if s not in self.skills]
        if bad:
            raise ValueError(f"Unknown skill(s): {', '.join(bad)}")
        return set(skills)

    def closure(self, skills):
        out, stack = set(), list(skills)
        while stack:
            s = stack.pop()
            if s in out:
                continue
            out.add(s)
            stack.extend(self.skills[s]["prereqs"])
        return out

    def _mult(self, skill, known):
        related = len(set(self.skills[skill]["related"]) & known)
        return max(MIN_DISCOUNT_MULT, 1.0 - DISCOUNT_PER_RELATED * related)

    def public_meta(self):
        return {
            "skills": [{"id": k, "name": v["name"], "weeks": v["weeks"]} for k, v in self.skills.items()],
            "roles": [{"id": k, "name": v["name"]} for k, v in self.roles.items()],
            "jobs": [{"id": j["id"], "title": j["title"], "city": j["city"]} for j in self.jobs],
        }

    # ---------------------------------------------------------------- ANN match
    def features(self, have, job, years, education):
        req, nice = set(job["required"]), set(job["nice"])
        have = set(have)
        req_cov = len(req & have) / len(req)
        nice_cov = len(nice & have) / len(nice) if nice else 0.0
        missing = len(req - have) / 6.0
        gap = float(np.clip((years - job["min_years"]) / 4.0, -1.0, 1.0))
        edu_ok = 1.0 if job["education"] == "any" or education in ("bachelor", "master") else 0.0
        return [req_cov, nice_cov, missing, gap, edu_ok]

    @classmethod
    def build(cls, model_dir, retrain=False):
        data = json.loads((DATA_DIR / "career.json").read_text(encoding="utf-8"))
        proto = cls.__new__(cls)
        proto.skills, proto.roles, proto.jobs = data["skills"], data["roles"], data["jobs"]

        def synth(rng, n):
            all_skills = list(proto.skills)
            X = []
            for _ in range(n):
                job = proto.jobs[rng.integers(len(proto.jobs))]
                p = rng.uniform(0, 1)
                have = {s for s in job["required"] if rng.random() < p}
                have |= {s for s in job["nice"] if rng.random() < 0.5 * p}
                have |= {all_skills[i] for i in rng.integers(0, len(all_skills), rng.poisson(2))}
                years = int(rng.integers(0, 7))
                edu = EDUCATION[int(rng.choice(3, p=[0.2, 0.6, 0.2]))]
                X.append(proto.features(have, job, years, edu))
            return np.array(X)

        def train():
            rng = np.random.default_rng(11)
            X = synth(rng, 24000)
            p = true_match_prob(X)
            y = (rng.random(len(X)) < p).astype(float)
            Xtr, ytr, Xte, pte = X[:20000], y[:20000], X[20000:], p[20000:]
            mlp = MLP([5, 16, 8, 1], "binary", "tanh", seed=2)
            mlp.fit(Xtr, ytr, epochs=50, lr=0.005, batch=128)
            ann_mae = float(np.mean(np.abs(mlp.predict(Xte) - pte)))

            sub_X, sub_y = Xtr[:3000], ytr[:3000]

            def obj(theta):
                return float(np.mean((_sigmoid(sub_X @ theta[:5] + theta[5]) - sub_y) ** 2))

            fit = pso(obj, [(-10, 10)] * 6, particles=30, iters=60, seed=3)
            theta = np.array(fit["x"])
            lin_mae = float(np.mean(np.abs(_sigmoid(Xte @ theta[:5] + theta[5]) - pte)))
            return mlp, {
                "task": "binary", "architecture": "5-16-8-1 tanh", "samples": 20000,
                "ann_mae_vs_truth": round(ann_mae, 4), "linear_mae_vs_truth": round(lin_mae, 4),
                "linear_scorer": {"w": [round(float(v), 3) for v in theta[:5]],
                                  "b": round(float(theta[5]), 3), "pso_mse": round(fit["f"], 4)},
                "note": "Trained on synthetic candidates; replace with real hiring outcomes.",
            }

        mlp, metrics = load_or_train(Path(model_dir) / "career.json", cls.VERSION, train, retrain)
        return cls(mlp, metrics)

    def match(self, have, years=0, education="bachelor"):
        have = self.check_skills(have)
        rows = [self.features(have, j, years, education) for j in self.jobs]
        probs = self.mlp.predict(np.array(rows))
        out = []
        for job, f, p in zip(self.jobs, rows, probs):
            missing = [s for s in job["required"] if s not in have]
            contrib = {n: round(float(w * x), 2) for n, w, x in zip(FEATURE_NAMES, self.linear["w"], f)}
            out.append({
                "id": job["id"], "title": job["title"], "city": job["city"],
                "probability": round(float(p), 3),
                "fit": "strong" if p >= 0.75 else "possible" if p >= 0.45 else "stretch",
                "required_covered": round(f[0], 2),
                "missing_required": missing,
                "missing_names": [self.skills[s]["name"] for s in missing],
                "min_years": job["min_years"], "education": job["education"],
                "linear_contributions": contrib,
            })
        out.sort(key=lambda r: (-r["probability"], r["title"]))
        return {"matches": out, "linear_weights": dict(zip(FEATURE_NAMES, self.linear["w"]))}

    # ---------------------------------------------------------------- A* path
    def learning_path(self, have, role):
        if role not in self.roles:
            raise ValueError(f"Unknown role: {role}")
        have = self.check_skills(have)
        role_req = set(self.roles[role]["required"])
        missing_role = role_req - have
        base = {"role": role, "role_name": self.roles[role]["name"]}
        if not missing_role:
            return {**base, "already_qualified": True, "steps": [], "total_weeks": 0.0,
                    "naive_weeks": 0.0, "expanded_astar": 0, "expanded_dijkstra": 0}
        needed = sorted(self.closure(missing_role) - have)

        def neighbors(state):
            known = have | state
            for s in needed:
                if s not in state and all(p in known for p in self.skills[s]["prereqs"]):
                    yield state | {s}, self.skills[s]["weeks"] * self._mult(s, known), s

        reachable = have | set(needed)
        lower = {s: self.skills[s]["weeks"] * max(
            MIN_DISCOUNT_MULT, 1.0 - DISCOUNT_PER_RELATED * len(set(self.skills[s]["related"]) & reachable))
            for s in needed}

        def h(state):
            # every skill still required (role skills + their prerequisites) must be learned
            # at least once, at best with the largest possible discount
            todo = self.closure(missing_role - state) - have - state
            return sum(lower[s] for s in todo)

        def goal(state):
            return missing_role <= state

        res = astar(frozenset(), goal, neighbors, h)
        ref = astar(frozenset(), goal, neighbors)
        steps, known, cum = [], set(have), 0.0
        for s in res["actions"]:
            mult = self._mult(s, known)
            weeks = self.skills[s]["weeks"] * mult
            cum += weeks
            steps.append({"skill": s, "name": self.skills[s]["name"],
                          "base_weeks": self.skills[s]["weeks"], "weeks": round(weeks, 2),
                          "discount_pct": round((1 - mult) * 100), "cumulative_weeks": round(cum, 2),
                          "required_by_role": s in role_req})
            known.add(s)
        # naive order: prerequisites first, following the order the role lists its skills
        naive, seen = [], set()

        def visit(s):
            if s in seen or s in have:
                return
            seen.add(s)
            for p in self.skills[s]["prereqs"]:
                visit(p)
            naive.append(s)

        for s in self.roles[role]["required"]:
            visit(s)
        known, naive_cost = set(have), 0.0
        for s in naive:
            naive_cost += self.skills[s]["weeks"] * self._mult(s, known)
            known.add(s)
        return {**base, "already_qualified": False, "steps": steps,
                "total_weeks": round(res["cost"], 2), "naive_weeks": round(naive_cost, 2),
                "expanded_astar": res["expanded"], "expanded_dijkstra": ref["expanded"]}

    # ------------------------------------------------------------------ GA plan
    def _value(self, known):
        total = 0.0
        for j in self.jobs:
            req, nice = set(j["required"]), set(j["nice"])
            cov = len(req & known) / len(req)
            total += cov + (1.0 if cov == 1.0 else 0.0)
            total += 0.15 * (len(nice & known) / len(nice) if nice else 0.0)
        return total

    def _qualified(self, known):
        return [j["title"] for j in self.jobs if set(j["required"]) <= known]

    def _order(self, learned, have):
        order, known, left = [], set(have), set(learned)
        while left:
            ready = sorted(s for s in left if all(p in known for p in self.skills[s]["prereqs"]))
            s = ready[0]
            order.append(s)
            known.add(s)
            left.remove(s)
        return order

    def study_plan(self, have, weeks, seed=0):
        have = self.check_skills(have)
        if weeks <= 0:
            raise ValueError("weeks must be positive")
        cands = [s for s in self.skills if s not in have]
        cost_of = lambda learned: float(sum(self.skills[s]["weeks"] for s in learned))

        def learned_from(sel):
            return self.closure(sel) - have

        def fitness(bits):
            learned = learned_from({c for c, b in zip(cands, bits) if b})
            over = max(0.0, cost_of(learned) - weeks)
            return self._value(have | learned) - 8.0 * over / weeks - 0.001 * cost_of(learned)

        # greedy baseline: best value-per-week that still fits
        g_learned = set()
        while True:
            best, best_ratio = None, 0.0
            base_v, base_c = self._value(have | g_learned), cost_of(g_learned)
            for s in cands:
                if s in g_learned:
                    continue
                trial = g_learned | (self.closure({s}) - have)
                c = cost_of(trial)
                if c > weeks:
                    continue
                gain = self._value(have | trial) - base_v
                ratio = gain / max(c - base_c, 0.1)
                if gain > 0 and ratio > best_ratio:
                    best, best_ratio = trial, ratio
            if best is None:
                break
            g_learned = best

        greedy_bits = [1 if c in g_learned else 0 for c in cands]
        ga = ga_binary(len(cands), fitness, pop_size=70, generations=90, seed=seed,
                       init_prob=0.12, seeds=[greedy_bits])
        sel = {c for c, b in zip(cands, ga["best"]) if b}
        while cost_of(learned_from(sel)) > weeks and sel:      # repair
            full = self._value(have | learned_from(sel))

            def loss(s):
                rest = sel - {s}
                saved = cost_of(learned_from(sel)) - cost_of(learned_from(rest))
                return (full - self._value(have | learned_from(rest))) / max(saved, 0.1)

            sel.remove(min(sel, key=loss))
        learned = learned_from(sel)

        step = max(1, len(ga["history"]) // 40)
        return {
            "budget_weeks": weeks, "used_weeks": cost_of(learned),
            "skills": [{"skill": s, "name": self.skills[s]["name"], "weeks": self.skills[s]["weeks"]}
                       for s in self._order(learned, have)],
            "qualified_before": self._qualified(have),
            "qualified_after": self._qualified(have | learned),
            "value_ga": round(self._value(have | learned), 3),
            "value_greedy": round(self._value(have | g_learned), 3),
            "value_start": round(self._value(have), 3),
            "history": [round(v, 3) for v in ga["history"][::step]],
            "evaluations": ga["evaluations"],
        }
